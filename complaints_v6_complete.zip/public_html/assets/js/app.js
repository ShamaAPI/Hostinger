// ============================================================
// app.js — النسخة v6 الكاملة
// ✅ إصلاح: الشكاوى في لوحة التحكم
// ✅ إصلاح: رد العميل + مرفقاته في صفحة التتبع
// ✅ جديد: رقم شكوى حسب النوع (ELC-123456)
// ✅ جديد: لوحة التحكم تُفتح من dashboard.php فقط
// ✅ جديد: فلترة الشكاوى بالحالة/الفئة/البحث
// ✅ جديد: ألوان مميزة لكل حالة
// ✅ جديد: تقرير شهري كامل
// ✅ جديد: إدارة المستخدمين (إضافة/حذف)
// ✅ إزالة: عدد الشكاوى من الصفحة الرئيسية
// ============================================================

// ==========================================
// CONFIG
// ==========================================
const STATUS_CONFIG = {
    'تم الاستلام':   { cls: 'status-received',    color: '#3b82f6', bg: '#dbeafe', label: 'تم الاستلام'   },
    'قيد المراجعة': { cls: 'status-reviewing',   color: '#f59e0b', bg: '#fef3c7', label: 'قيد المراجعة'  },
    'جاري التنفيذ': { cls: 'status-in-progress', color: '#10b981', bg: '#d1fae5', label: 'جاري التنفيذ'  },
    'تم الحل':      { cls: 'status-resolved',    color: '#059669', bg: '#dcfce7', label: 'تم الحل'       },
    'مغلقة':        { cls: 'status-closed',      color: '#6b7280', bg: '#f1f5f9', label: 'مغلقة'         },
    'مرفوضة':       { cls: 'status-rejected',    color: '#ef4444', bg: '#fee2e2', label: 'مرفوضة'        },
};

const CATEGORY_CONFIG = {
    'نظافة':  { prefix: 'CLN', icon: '🗑️',  color: '#84cc16' },
    'كهرباء': { prefix: 'ELC', icon: '⚡',  color: '#f59e0b' },
    'مياه':   { prefix: 'WTR', icon: '💧',  color: '#3b82f6' },
    'طرق':    { prefix: 'RDW', icon: '🛣️',  color: '#8b5cf6' },
    'فساد':   { prefix: 'CRP', icon: '🚨',  color: '#ef4444' },
    'أخرى':   { prefix: 'GEN', icon: '📋',  color: '#6b7280' },
};

// ==========================================
// STORE
// ==========================================
const Store = {
    data: { currentUser: null },
    _cache: {},

    async api(endpoint, method = 'GET', body = null) {
        const options = { method, headers: {'Content-Type':'application/json'}, credentials:'include' };
        if (body) options.body = JSON.stringify(body);
        try {
            const response = await fetch(`api/${endpoint}`, options);
            if (response.status === 401) { navigateTo('login'); return {success:false}; }
            if (response.status === 403) { showNotification('غير مصرح', 'error'); return {success:false}; }
            const text = await response.text();
            if (!text.trim()) return {success:false, message:'استجابة فارغة'};
            const clean = text.trim().replace(/^\uFEFF/,'');
            if (!clean.startsWith('{') && !clean.startsWith('[')) {
                console.error('Non-JSON:', clean.substring(0,300));
                return {success:false, message:'خطأ في الخادم'};
            }
            return JSON.parse(clean);
        } catch(e) {
            console.error('API Error:', e);
            return {success:false, message:'خطأ في الاتصال'};
        }
    },

    init() {
        // استعادة بيانات المستخدم من dashboard login
        const saved = sessionStorage.getItem('dashboard_user');
        if (saved) {
            try { this.data.currentUser = JSON.parse(saved); } catch(e) {}
        }
    },

    async login(email, password) {
        const r = await this.api('login.php','POST',{email,password});
        if (r.success) { this.data.currentUser = r.user; sessionStorage.setItem('dashboard_user', JSON.stringify(r.user)); return r.user; }
        return null;
    },
    logout() { this.data.currentUser = null; sessionStorage.removeItem('dashboard_user'); this._cache = {}; },

    invalidateCache(key) { if (key) delete this._cache[key]; else this._cache = {}; },

    async getTrackData(query) {
        const key = 'track_' + query;
        if (this._cache[key]) return this._cache[key];
        const r = await this.api(`track.php?query=${encodeURIComponent(query)}`);
        if (r.success) this._cache[key] = r;
        return r;
    },
    async addComplaint(c)      { return await this.api('submit.php','POST',c); },
    async addComment(cid,msg)  { return await this.api('admin.php?action=add_comment','POST',{complaint_id:cid,message:msg}); },
    async getStats()           { const r=await this.api('admin.php?action=stats'); return r.success?r.stats:{total:0,open:0,closed:0,inProgress:0,avgTime:0}; },
    async getComplaints(params='') { const r=await this.api('admin.php?action=list'+params); return r.complaints||[]; },
    async getUsers()           { const r=await this.api('admin.php?action=list_users'); return r.users||[]; },
    async updateComplaint(id,updates) { if(updates.status) return await this.api('admin.php?action=update_status','POST',{id,status:updates.status}); },
    async addUser(d)           { return await this.api('admin.php?action=add_user','POST',d); },
    async deleteUser(id)       { return await this.api('admin.php?action=delete_user','POST',{id}); },
    async getMonthlyReport(m)  { const r=await this.api(`admin.php?action=monthly_report&month=${m}`); return r; },
};
Store.init();

// ==========================================
// ROUTER
// ==========================================
let currentPage = 'home';

function navigateTo(page, params={}) {
    currentPage = page;
    window.scrollTo(0,0);
    closeMobileMenu();
    const nav = document.getElementById('public-nav');
    const adminPages = ['admin','admin-complaints','admin-users','admin-reports','admin-complaint-detail','agent'];
    if (adminPages.includes(page)) nav?.classList.add('hidden');
    else nav?.classList.remove('hidden');
    renderPage(params);
}

async function renderPage(params={}) {
    const main = document.getElementById('main-content');
    if (!main) return;
    const spinner = `<div class="min-h-screen flex flex-col items-center justify-center gap-3">
        <div class="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p class="text-muted text-sm">جاري التحميل...</p></div>`;
    try {
        let html = '';
        switch(currentPage) {
            case 'home':                   html = renderHomePage(); break;
            case 'submit':                 html = renderSubmitPage(); setTimeout(()=>initSubmitForm(),0); break;
            case 'track':                  html = renderTrackPage(); break;
            case 'track-result':           main.innerHTML=spinner; html=await renderTrackResultPage(params.id); break;
            case 'login':                  html = renderLoginPage(); break;
            case 'admin':                  main.innerHTML=spinner; html=await renderAdminDashboard(); break;
            case 'admin-complaints':       main.innerHTML=spinner; html=await renderAdminComplaints(params); break;
            case 'admin-complaint-detail': main.innerHTML=spinner; html=await renderAdminComplaintDetail(params.id); break;
            case 'admin-users':            main.innerHTML=spinner; html=await renderAdminUsers(); break;
            case 'admin-reports':          main.innerHTML=spinner; html=await renderAdminReports(); break;
            case 'agent':                  main.innerHTML=spinner; html=await renderAgentPanel(); break;
            case 'success':                html = renderSuccessPage(params.complaint); break;
            default:                       html = renderHomePage();
        }
        if (html) main.innerHTML = html;
    } catch(e) {
        console.error('Render Error:', e);
        main.innerHTML = `<div class="p-8 text-center"><p class="text-danger font-bold">حدث خطأ</p><p class="text-muted text-sm mt-2">${e.message}</p><button onclick="navigateTo('home')" class="mt-4 btn-primary px-6 py-2 rounded-lg">الرئيسية</button></div>`;
    }
    requestAnimationFrame(()=>{ document.querySelectorAll('.animate-fade-in-up').forEach(el=>el.style.opacity='1'); });
}

// ==========================================
// UTILS
// ==========================================
function escapeHtml(str) {
    if (str===null||str===undefined) return '';
    if (typeof str==='object') return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function getStatusClass(s) {
    return STATUS_CONFIG[s]?.cls || 'status-received';
}

function statusBadge(s) {
    const cfg = STATUS_CONFIG[s] || STATUS_CONFIG['تم الاستلام'];
    return `<span class="status-badge" style="background:${cfg.bg};color:${cfg.color};border:1px solid ${cfg.color}33">${cfg.label}</span>`;
}

function priorityClass(p) {
    return {'منخفض':'low','متوسط':'medium','مرتفع':'high','عاجل':'urgent'}[p]||'medium';
}

function categoryIcon(cat) {
    return CATEGORY_CONFIG[cat]?.icon || '📋';
}

function formatDate(d) {
    if (!d) return '';
    return new Date(d).toLocaleDateString('ar-EG',{year:'numeric',month:'long',day:'numeric'});
}
function formatTime(d) {
    if (!d) return '';
    return new Date(d).toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit'});
}

function showNotification(m, t='info') {
    const c = document.getElementById('notifications');
    if (!c) return;
    const icons = {success:'✓',error:'✕',info:'ℹ'};
    const d = document.createElement('div');
    d.className = `notification flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-white text-sm ${t==='success'?'bg-success':t==='error'?'bg-danger':'bg-info'}`;
    d.innerHTML = `<span class="font-bold">${icons[t]||'ℹ'}</span><span>${escapeHtml(m)}</span>`;
    c.appendChild(d);
    setTimeout(()=>{ d.style.opacity='0'; d.style.transition='opacity 0.3s'; setTimeout(()=>d.remove(),300); }, 3500);
}

function toggleMobileMenu() { document.getElementById('mobile-menu')?.classList.toggle('hidden'); }
function closeMobileMenu()  { document.getElementById('mobile-menu')?.classList.add('hidden'); }

document.addEventListener('click', e=>{
    const menu = document.getElementById('mobile-menu');
    if (menu && !menu.classList.contains('hidden') && !e.target.closest('[onclick="toggleMobileMenu()"]') && !menu.contains(e.target))
        menu.classList.add('hidden');
});

document.addEventListener('change', e=>{
    if (e.target.id==='reply-file') {
        const s = document.getElementById('file-name');
        if (s) s.textContent = e.target.files[0]?.name || 'لم يتم اختيار ملف';
    }
});

function logout() { Store.logout(); showNotification('تم تسجيل الخروج','success'); navigateTo('home'); }

// ==========================================
// HOME PAGE — بدون أعداد الشكاوى
// ==========================================
function renderHomePage() {
    return `
    <div class="bg-pattern min-h-screen">
        <section class="relative overflow-hidden py-20 sm:py-28">
            <div class="relative max-w-7xl mx-auto px-4 sm:px-6 text-center">
                <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center mx-auto mb-6">
                    <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                </div>
                <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-secondary mb-4">نظام إدارة الشكاوى</h1>
                <p class="text-lg text-muted mb-8">حدائق القبة — قدّم شكواك وتابع حالتها بسهولة</p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <button onclick="navigateTo('submit')" class="btn-primary px-8 py-4 rounded-xl text-lg font-semibold shadow-lg">قدم شكواك الآن</button>
                    <button onclick="navigateTo('track')" class="bg-white border-2 border-slate-200 text-secondary px-8 py-4 rounded-xl text-lg font-semibold hover:border-primary transition-colors">تتبع شكوى</button>
                </div>
            </div>
        </section>

        <section class="py-16 bg-white">
            <div class="max-w-7xl mx-auto px-4">
                <h2 class="text-2xl font-bold text-center text-secondary mb-10">أنواع الشكاوى</h2>
                <div class="grid grid-cols-3 sm:grid-cols-6 gap-4">
                    ${Object.entries(CATEGORY_CONFIG).map(([name,cfg])=>`
                    <div class="bg-slate-50 rounded-xl p-5 text-center card-hover cursor-pointer border-2 border-transparent hover:border-primary transition-all" onclick="navigateTo('submit')">
                        <div class="text-3xl mb-2">${cfg.icon}</div>
                        <span class="text-sm font-medium text-secondary">${name}</span>
                    </div>`).join('')}
                </div>
            </div>
        </section>

        <footer class="bg-secondary text-white py-10 text-center">
            <p class="font-bold mb-1">نظام إدارة شكاوى حدائق القبة</p>
            <p class="text-slate-400 text-sm">جميع الحقوق محفوظة © ${new Date().getFullYear()}</p>
        </footer>
    </div>`;
}

// ==========================================
// SUBMIT FORM
// ==========================================
let formData = {}; let currentStep = 1; const totalSteps = 5;

function initSubmitForm() {
    formData = {category:'',title:'',description:'',priority:'متوسط',address:'',name:'',phone:'',email:'',isAnonymous:false};
    currentStep = 1; updateFormContainer();
}

function renderProgressBar(step) {
    const steps = ['النوع','التفاصيل','الموقع','المرفقات','بياناتك'];
    return `<div class="mb-8 flex items-center">
        ${steps.map((s,i)=>`
        ${i>0?`<div class="flex-1 h-1 mx-1 rounded-full ${i<step?'bg-success':'bg-slate-200'}"></div>`:''}
        <div class="flex flex-col items-center">
            <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold mb-1 transition-colors
                ${i+1<step?'bg-success text-white':i+1===step?'bg-primary text-white':'bg-slate-200 text-muted'}">
                ${i+1<step?'✓':i+1}
            </div>
            <span class="text-xs hidden sm:block ${i+1===step?'text-primary font-medium':'text-muted'}">${s}</span>
        </div>`).join('')}
    </div>`;
}

function renderSubmitPage() {
    return `<div class="min-h-screen bg-pattern py-8">
        <div class="max-w-3xl mx-auto px-4">
            <div class="mb-6 flex items-center gap-3">
                <button onclick="navigateTo('home')" class="text-muted hover:text-secondary p-1">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                </button>
                <h2 class="text-2xl font-bold">تقديم شكوى جديدة</h2>
            </div>
            <div id="form-container" class="bg-white rounded-2xl shadow-sm p-8"></div>
        </div></div>`;
}

function renderStep(s) {
    const bar = renderProgressBar(s);
    if (s===1) return bar+renderCategoryStep();
    if (s===2) return bar+renderDetailsStep();
    if (s===3) return bar+renderLocationStep();
    if (s===4) return bar+renderAttachmentsStep();
    return bar+renderUserInfoStep();
}

function renderCategoryStep() {
    return `<h3 class="text-lg font-semibold mb-6">اختر نوع الشكوى</h3>
    <div class="grid grid-cols-3 gap-3 mb-8">
        ${Object.entries(CATEGORY_CONFIG).map(([name,cfg])=>`
        <div class="category-card bg-slate-50 border-2 border-slate-200 rounded-xl p-4 text-center cursor-pointer hover:border-primary transition-all ${formData.category===name?'selected':''}"
             onclick="selectCategory('${name}',this)" style="${formData.category===name?`border-color:${cfg.color}`:''}">
            <div class="text-2xl mb-1">${cfg.icon}</div>
            <span class="text-sm font-medium">${name}</span>
            <div class="text-xs text-muted mt-1">${cfg.prefix}-XXXXXX</div>
        </div>`).join('')}
    </div>
    <div class="flex justify-end">
        <button onclick="nextStep()" class="btn-primary px-8 py-3 rounded-xl font-medium ${!formData.category?'opacity-50 cursor-not-allowed':''}">التالي ←</button>
    </div>`;
}

function renderDetailsStep() {
    return `<h3 class="text-lg font-semibold mb-6">تفاصيل الشكوى</h3>
    <div class="space-y-4 mb-8">
        <div><label class="block text-sm font-medium mb-1">عنوان الشكوى <span class="text-danger">*</span></label>
            <input type="text" id="title" value="${escapeHtml(formData.title)}"
                class="w-full px-4 py-3 border-2 rounded-xl input-focus" placeholder="مثال: انقطاع المياه في شارع ..." maxlength="200"></div>
        <div><label class="block text-sm font-medium mb-1">وصف المشكلة <span class="text-danger">*</span></label>
            <textarea id="description" rows="4" class="w-full px-4 py-3 border-2 rounded-xl input-focus resize-none"
                placeholder="اشرح المشكلة بالتفصيل (20 حرف على الأقل)..." maxlength="2000">${escapeHtml(formData.description)}</textarea></div>
        <div><label class="block text-sm font-medium mb-1">الأولوية</label>
            <select id="priority" class="w-full px-4 py-3 border-2 rounded-xl input-focus">
                ${['منخفض','متوسط','مرتفع','عاجل'].map(p=>`<option value="${p}" ${formData.priority===p?'selected':''}>${p}</option>`).join('')}
            </select></div>
    </div>
    <div class="flex justify-between">
        <button onclick="prevStep()" class="px-6 py-3 rounded-xl border-2 border-slate-200 hover:bg-slate-50">→ السابق</button>
        <button onclick="nextStep()" class="btn-primary px-8 py-3 rounded-xl font-medium">التالي ←</button>
    </div>`;
}

function renderLocationStep() {
    return `<h3 class="text-lg font-semibold mb-6">الموقع (اختياري)</h3>
    <div class="mb-8"><label class="block text-sm font-medium mb-1">العنوان التفصيلي</label>
        <textarea id="address" rows="3" class="w-full px-4 py-3 border-2 rounded-xl input-focus resize-none"
            placeholder="مثال: شارع الجمهورية، أمام مسجد ...">${escapeHtml(formData.address)}</textarea></div>
    <div class="flex justify-between">
        <button onclick="prevStep()" class="px-6 py-3 rounded-xl border-2 border-slate-200 hover:bg-slate-50">→ السابق</button>
        <button onclick="nextStep()" class="btn-primary px-8 py-3 rounded-xl font-medium">التالي ←</button>
    </div>`;
}

function renderAttachmentsStep() {
    return `<h3 class="text-lg font-semibold mb-6">المرفقات (اختياري)</h3>
    <div class="file-upload-zone rounded-xl p-10 text-center mb-4 cursor-pointer" onclick="document.getElementById('attach-file').click()">
        <div class="text-4xl mb-3">📎</div>
        <p class="text-muted text-sm">اضغط لرفع صورة أو PDF</p>
        <p class="text-xs text-muted mt-1">الحجم الأقصى: 5MB</p>
        <input type="file" id="attach-file" class="hidden" accept="image/*,.pdf" onchange="showAttachName(this)">
    </div>
    <p id="attach-name" class="text-sm text-success text-center"></p>
    <div class="flex justify-between mt-6">
        <button onclick="prevStep()" class="px-6 py-3 rounded-xl border-2 border-slate-200 hover:bg-slate-50">→ السابق</button>
        <button onclick="nextStep()" class="btn-primary px-8 py-3 rounded-xl font-medium">التالي ←</button>
    </div>`;
}
function showAttachName(input) { const p=document.getElementById('attach-name'); if(p&&input.files[0]) p.textContent='✓ '+input.files[0].name; }

function renderUserInfoStep() {
    return `<h3 class="text-lg font-semibold mb-6">بياناتك الشخصية</h3>
    <div class="space-y-4 mb-6">
        <div><label class="block text-sm font-medium mb-1">الاسم الكامل <span class="text-danger">*</span></label>
            <input type="text" id="user-name" value="${escapeHtml(formData.name)}" class="w-full px-4 py-3 border-2 rounded-xl input-focus" placeholder="محمد أحمد"></div>
        <div><label class="block text-sm font-medium mb-1">رقم الهاتف <span class="text-danger">*</span></label>
            <input type="tel" id="user-phone" value="${escapeHtml(formData.phone)}" class="w-full px-4 py-3 border-2 rounded-xl input-focus" placeholder="01012345678" maxlength="11">
            <p class="text-xs text-muted mt-1">يُستخدم لتتبع الشكوى</p></div>
        <div><label class="block text-sm font-medium mb-1">البريد الإلكتروني (اختياري)</label>
            <input type="email" id="user-email" value="${escapeHtml(formData.email)}" class="w-full px-4 py-3 border-2 rounded-xl input-focus" placeholder="example@mail.com"></div>
        <label class="flex items-center gap-3 cursor-pointer select-none">
            <input type="checkbox" id="is-anonymous" ${formData.isAnonymous?'checked':''} class="w-4 h-4 accent-primary">
            <span class="text-sm text-muted">تقديم بشكل مجهول</span>
        </label>
    </div>
    <div class="flex justify-between">
        <button onclick="prevStep()" class="px-6 py-3 rounded-xl border-2 border-slate-200 hover:bg-slate-50">→ السابق</button>
        <button onclick="submitComplaint()" id="submit-btn" class="btn-primary px-8 py-3 rounded-xl font-medium">تقديم الشكوى</button>
    </div>`;
}

function selectCategory(c,el) {
    formData.category=c;
    document.querySelectorAll('.category-card').forEach(card=>{ card.classList.remove('selected'); card.style.borderColor=''; });
    el.classList.add('selected');
    el.style.borderColor = CATEGORY_CONFIG[c]?.color || '';
    const btn=document.querySelector('button[onclick="nextStep()"]');
    if(btn) btn.classList.remove('opacity-50','cursor-not-allowed');
}
function nextStep() {
    if(currentStep===1&&!formData.category) return showNotification('اختر نوع الشكوى أولاً','error');
    if(currentStep===2) {
        formData.title=document.getElementById('title')?.value.trim();
        formData.description=document.getElementById('description')?.value.trim();
        formData.priority=document.getElementById('priority')?.value;
        if(!formData.title) return showNotification('أدخل عنوان الشكوى','error');
        if(formData.title.length<5) return showNotification('العنوان قصير جداً','error');
        if(!formData.description||formData.description.length<20) return showNotification('الوصف قصير جداً (20 حرف)','error');
    }
    if(currentStep===3) formData.address=document.getElementById('address')?.value.trim();
    if(currentStep<totalSteps) { currentStep++; updateFormContainer(); }
}
function prevStep() { if(currentStep>1){currentStep--;updateFormContainer();} }
function updateFormContainer() { const c=document.getElementById('form-container'); if(c) c.innerHTML=renderStep(currentStep); }

async function submitComplaint() {
    formData.name        = document.getElementById('user-name')?.value.trim();
    formData.phone       = document.getElementById('user-phone')?.value.trim();
    formData.email       = document.getElementById('user-email')?.value.trim();
    formData.isAnonymous = document.getElementById('is-anonymous')?.checked;
    if(!formData.name) return showNotification('أدخل اسمك','error');
    if(!formData.phone) return showNotification('أدخل رقم هاتفك','error');
    if(!/^01[0125][0-9]{8}$/.test(formData.phone)) return showNotification('رقم الهاتف غير صحيح','error');
    if(formData.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) return showNotification('البريد غير صحيح','error');
    const btn=document.getElementById('submit-btn');
    if(btn){btn.disabled=true;btn.textContent='جاري الإرسال...';}
    const result=await Store.addComplaint(formData);
    if(result.success) {
        navigateTo('success',{complaint:{id:result.complaint_id,code:result.complaint_code,category:formData.category}});
    } else {
        showNotification(result.message||'حدث خطأ','error');
        if(btn){btn.disabled=false;btn.textContent='تقديم الشكوى';}
    }
}

// ==========================================
// SUCCESS PAGE
// ==========================================
function renderSuccessPage(c) {
    const catCfg = CATEGORY_CONFIG[c?.category] || CATEGORY_CONFIG['أخرى'];
    setTimeout(()=>{
        const canvas=document.getElementById('qrcode');
        if(canvas&&c?.code&&typeof QRCode!=='undefined') {
            QRCode.toCanvas(canvas,`شكوى ${c.code}`,{width:160},err=>{ if(err) canvas.style.display='none'; });
        } else if(canvas) canvas.style.display='none';
    },200);
    return `
    <div class="min-h-screen bg-pattern py-12 flex items-center">
        <div class="max-w-lg mx-auto px-4 w-full">
            <div class="bg-white rounded-2xl shadow-sm p-10 text-center">
                <div class="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
                    <svg class="w-10 h-10 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                </div>
                <h2 class="text-2xl font-bold mb-2">تم تقديم شكواك بنجاح!</h2>
                <p class="text-muted mb-6">احتفظ برقم الشكوى لمتابعة حالتها</p>
                <div class="bg-slate-50 border-2 rounded-2xl p-6 mb-4">
                    <p class="text-xs text-muted mb-1">رقم الشكوى</p>
                    <p class="text-3xl font-bold text-primary font-mono">${escapeHtml(c?.code||'')}</p>
                    <div class="flex items-center justify-center gap-2 mt-2">
                        <span class="text-2xl">${catCfg.icon}</span>
                        <span class="text-sm text-muted">${escapeHtml(c?.category||'')}</span>
                    </div>
                </div>
                <canvas id="qrcode" class="mx-auto mb-4 rounded-lg"></canvas>
                <p class="text-xs text-muted mb-8">امسح QR Code لمتابعة شكواك</p>
                <div class="flex flex-col sm:flex-row gap-3">
                    <button onclick="navigateTo('track-result',{id:'${escapeHtml(c?.code||'')}'})" class="flex-1 btn-primary py-3 rounded-xl font-medium">تابع الشكوى</button>
                    <button onclick="navigateTo('home')" class="flex-1 py-3 rounded-xl border-2 border-slate-200 font-medium hover:bg-slate-50">الرئيسية</button>
                </div>
            </div>
        </div>
    </div>`;
}

// ==========================================
// TRACK PAGE
// ==========================================
function renderTrackPage() {
    return `<div class="min-h-screen bg-pattern py-12">
        <div class="max-w-lg mx-auto px-4">
            <div class="bg-white rounded-2xl shadow-sm p-8">
                <div class="text-center mb-8">
                    <div class="text-4xl mb-3">🔍</div>
                    <h2 class="text-xl font-bold mb-1">تتبع الشكوى</h2>
                    <p class="text-muted text-sm">أدخل رقم الشكوى (مثال: ELC-123456) أو رقم هاتفك</p>
                </div>
                <input type="text" id="track-input" class="w-full px-4 py-4 border-2 rounded-xl text-lg mb-4 input-focus text-center font-mono"
                    placeholder="ELC-123456 أو 01012345678" onkeydown="if(event.key==='Enter') trackComplaint()">
                <button onclick="trackComplaint()" class="w-full btn-primary py-4 rounded-xl font-semibold text-lg">بحث</button>
            </div>
        </div></div>`;
}

async function trackComplaint() {
    const input = document.getElementById('track-input')?.value.trim();
    if (!input) return showNotification('أدخل رقم الشكوى أو الهاتف','error');
    Store.invalidateCache('track_'+input);
    const res = await Store.getTrackData(input);
    if (res.success) navigateTo('track-result',{id:input});
    else showNotification(res.message||'لم يتم العثور على نتائج','error');
}

async function renderTrackResultPage(query) {
    const res = await Store.getTrackData(query);
    if (!res.success) return `<div class="p-8 text-center text-muted"><p class="text-5xl mb-4">😕</p><p>لا توجد نتائج لهذا الرقم</p><button onclick="navigateTo('track')" class="mt-4 btn-primary px-6 py-2 rounded-lg">بحث جديد</button></div>`;

    const c        = res.complaint;
    const history  = res.history  || [];
    const comments = res.comments || [];
    const catCfg   = CATEGORY_CONFIG[c.category] || CATEGORY_CONFIG['أخرى'];

    return `
    <div class="min-h-screen bg-pattern py-12">
        <div class="max-w-3xl mx-auto px-4">
            <button onclick="navigateTo('track')" class="flex items-center gap-2 text-muted hover:text-secondary mb-6">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                بحث جديد
            </button>

            <!-- بطاقة الشكوى -->
            <div class="bg-white rounded-2xl shadow-sm p-6 mb-6">
                <div class="flex flex-wrap justify-between items-start gap-3 mb-4">
                    <div>
                        <div class="flex items-center gap-2 mb-1">
                            <span class="text-2xl">${catCfg.icon}</span>
                            <span class="font-mono text-sm font-bold text-primary">${escapeHtml(c.complaint_code||c.id)}</span>
                            <span class="text-xs text-muted">· ${escapeHtml(c.category)}</span>
                        </div>
                        <h2 class="text-xl font-bold">${escapeHtml(c.title)}</h2>
                        <p class="text-xs text-muted mt-1">${formatDate(c.created_at)}</p>
                    </div>
                    ${statusBadge(c.status)}
                </div>
                <p class="text-slate-600 bg-slate-50 rounded-xl p-4 leading-relaxed">${escapeHtml(c.description)}</p>
            </div>

            <!-- مراحل الشكوى / Timeline -->
            <div class="bg-white rounded-2xl shadow-sm p-6 mb-6">
                <h3 class="font-bold mb-6">مراحل الشكوى</h3>
                <div class="space-y-4">
                    ${history.length===0
                        ? '<p class="text-muted text-sm">لا يوجد سجل متاح</p>'
                        : history.map((x,i)=>{
                            const cfg=STATUS_CONFIG[x.status]||STATUS_CONFIG['تم الاستلام'];
                            return `<div class="timeline-item ${i>0?'opacity-70':''}">
                                <div class="timeline-dot" style="background:${cfg.color}"></div>
                                <div class="flex justify-between items-center">
                                    <span class="font-medium text-sm" style="color:${cfg.color}">${x.status}</span>
                                    <span class="text-xs text-muted">${formatDate(x.timestamp)}</span>
                                </div>
                            </div>`;
                        }).join('')}
                </div>
            </div>

            <!-- المحادثات -->
            <div class="bg-white rounded-2xl shadow-sm p-6 mb-6">
                <h3 class="font-bold mb-4">المحادثات والردود</h3>
                <div class="space-y-3 mb-4 max-h-96 overflow-y-auto" id="chat-box">
                    ${comments.length===0
                        ? '<p class="text-center text-muted py-8 text-sm">لا توجد ردود حتى الآن</p>'
                        : comments.map(x=>`
                        <div class="flex ${x.user_type==='customer'?'justify-end':'justify-start'}">
                            <div class="max-w-xs lg:max-w-md">
                                <div class="text-xs text-muted mb-1 ${x.user_type==='customer'?'text-left':'text-right'}">
                                    ${x.user_type==='admin'?'🏛️ الإدارة':x.user_type==='agent'?'👤 الموظف':'🙋 أنت'} · ${formatTime(x.created_at)}
                                </div>
                                <div class="px-4 py-3 rounded-2xl ${x.user_type==='customer'?'bg-primary text-white rounded-tl-sm':'bg-slate-100 text-slate-800 rounded-tr-sm'}">
                                    <p class="text-sm leading-relaxed">${escapeHtml(x.message)}</p>
                                    ${(x.file_path&&typeof x.file_path==='string')?renderAttachment(x.file_path):''}
                                </div>
                            </div>
                        </div>`).join('')}
                </div>
                <!-- نموذج رد العميل -->
                <div class="border-t pt-4">
                    <textarea id="customer-reply" class="w-full px-4 py-3 border-2 rounded-xl resize-none mb-3 input-focus text-sm" rows="2" placeholder="اكتب ردك هنا..."></textarea>
                    <div class="flex items-center gap-2 mb-3">
                        <label class="cursor-pointer bg-slate-100 hover:bg-slate-200 transition-colors p-2.5 rounded-lg" title="إرفاق ملف">
                            <svg class="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
                            <input type="file" id="reply-file" class="hidden" accept="image/*,.pdf">
                        </label>
                        <span id="file-name" class="text-xs text-muted">لم يتم اختيار ملف</span>
                    </div>
                    <button onclick="submitCustomerReply(${c.id},'${escapeHtml(query)}')" class="w-full btn-primary py-3 rounded-xl text-sm font-medium">إرسال الرد</button>
                </div>
            </div>
        </div>
    </div>`;
}

async function submitCustomerReply(id, query) {
    const msg       = document.getElementById('customer-reply')?.value.trim();
    const fileInput = document.getElementById('reply-file');
    if (!msg && (!fileInput||fileInput.files.length===0)) return showNotification('اكتب رداً أو أرفق ملفاً','error');
    const fd = new FormData();
    fd.append('complaint_id', id);
    fd.append('message', msg||'');
    if (fileInput?.files.length>0) fd.append('file',fileInput.files[0]);
    try {
        const res    = await fetch('api/admin.php?action=add_customer_reply',{method:'POST',body:fd,credentials:'include'});
        const text   = await res.text();
        const result = JSON.parse(text.trim());
        if (result.success) {
            showNotification('تم إرسال ردك بنجاح','success');
            Store.invalidateCache('track_'+query);
            navigateTo('track-result',{id:query});
        } else showNotification(result.message||'حدث خطأ','error');
    } catch(e) { showNotification('خطأ في الاتصال','error'); }
}

// ==========================================
// ATTACHMENT RENDERER
// ==========================================
function renderAttachment(filePath) {
    if (!filePath||typeof filePath!=='string') return '';
    const ext    = filePath.split('.').pop().toLowerCase();
    const name   = filePath.split('/').pop();
    const isImg  = ['jpg','jpeg','png','gif','webp'].includes(ext);
    const isPDF  = ext==='pdf';

    if (isImg) return `
        <div class="mt-2 rounded-xl overflow-hidden border border-slate-200 bg-white" style="max-width:280px">
            <div class="relative group cursor-pointer" onclick="openLightbox('${filePath}','${escapeHtml(name)}')">
                <img src="${filePath}" alt="${escapeHtml(name)}" class="w-full object-cover" style="max-height:160px;object-fit:cover"
                     onerror="this.parentElement.parentElement.innerHTML='<div class=\\'p-2 text-xs text-muted\\'>⚠️ تعذر تحميل الصورة</div>'">
                <div class="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <span class="text-white text-xs bg-black/50 px-2 py-1 rounded-full">🔍 معاينة</span>
                </div>
            </div>
            <div class="flex justify-between items-center px-3 py-1.5 bg-slate-50">
                <span class="text-xs text-muted truncate max-w-32">${escapeHtml(name)}</span>
                <a href="${filePath}" download="${escapeHtml(name)}" class="text-xs text-primary hover:underline flex-shrink-0 mr-1" onclick="event.stopPropagation()">⬇ تنزيل</a>
            </div>
        </div>`;

    if (isPDF) return `
        <div class="mt-2 flex items-center gap-2 bg-red-50 border border-red-100 rounded-xl px-3 py-2" style="max-width:280px">
            <span class="text-red-500 text-xl flex-shrink-0">📄</span>
            <span class="text-xs text-slate-700 truncate flex-1">${escapeHtml(name)}</span>
            <a href="${filePath}" target="_blank" class="text-xs text-slate-500 hover:text-slate-700 flex-shrink-0">فتح</a>
            <a href="${filePath}" download="${escapeHtml(name)}" class="text-xs text-primary hover:underline flex-shrink-0">⬇</a>
        </div>`;

    return `
        <div class="mt-2 flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2" style="max-width:280px">
            <span class="text-xl flex-shrink-0">📎</span>
            <span class="text-xs text-slate-700 truncate flex-1">${escapeHtml(name)}</span>
            <a href="${filePath}" download="${escapeHtml(name)}" class="text-xs text-primary hover:underline flex-shrink-0">⬇ تنزيل</a>
        </div>`;
}

function openLightbox(src, fileName) {
    document.getElementById('lightbox-overlay')?.remove();
    const overlay = document.createElement('div');
    overlay.id = 'lightbox-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,0.92);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:16px';
    overlay.onclick = e=>{ if(e.target===overlay) overlay.remove(); };
    overlay.innerHTML = `
        <div style="position:absolute;top:12px;left:0;right:0;display:flex;justify-content:space-between;align-items:center;padding:0 16px">
            <span style="color:#e2e8f0;font-size:12px;max-width:60%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(fileName)}</span>
            <div style="display:flex;gap:8px">
                <a href="${src}" download="${escapeHtml(fileName)}" style="background:#0d9488;color:#fff;padding:5px 12px;border-radius:8px;font-size:12px;text-decoration:none" onclick="event.stopPropagation()">⬇ تنزيل</a>
                <button onclick="document.getElementById('lightbox-overlay').remove()" style="background:#374151;color:#fff;border:none;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
            </div>
        </div>
        <img src="${src}" style="max-width:90vw;max-height:80vh;object-fit:contain;border-radius:12px" onerror="this.outerHTML='<p style=color:#ef4444>⚠️ تعذر تحميل الصورة</p>'">
        <p style="color:#64748b;font-size:11px;margin-top:10px">اضغط خارج الصورة للإغلاق · Escape للإغلاق</p>`;
    document.body.appendChild(overlay);
    const h = e=>{ if(e.key==='Escape'){overlay.remove();document.removeEventListener('keydown',h);} };
    document.addEventListener('keydown',h);
}

// ==========================================
// LOGIN PAGE (للموقع العام - غير مستخدمة عادةً)
// ==========================================
function renderLoginPage() {
    return `<div class="min-h-screen bg-pattern py-12 flex items-center">
        <div class="max-w-md mx-auto px-4 w-full">
            <div class="bg-white rounded-2xl shadow-sm p-8 text-center">
                <p class="text-muted mb-4">لوحة التحكم متاحة من رابط خاص</p>
                <a href="/dashboard.php" class="btn-primary px-8 py-3 rounded-xl font-semibold inline-block">الذهاب للوحة التحكم</a>
                <div class="mt-4"><button onclick="navigateTo('home')" class="text-muted text-sm hover:text-secondary">العودة للرئيسية</button></div>
            </div>
        </div></div>`;
}

// ==========================================
// ADMIN SIDEBAR
// ==========================================
function renderAdminSidebar(active) {
    const user = Store.data.currentUser;
    const links = [
        {page:'admin',                 key:'dashboard',   label:'لوحة التحكم', icon:'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'},
        {page:'admin-complaints',      key:'complaints',  label:'الشكاوى',     icon:'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2'},
        {page:'admin-users',           key:'users',       label:'المستخدمين',  icon:'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z'},
        {page:'admin-reports',         key:'reports',     label:'التقارير',    icon:'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z'},
    ];
    return `
    <aside class="sidebar fixed lg:static inset-y-0 right-0 w-64 bg-secondary text-white z-40 flex flex-col">
        <div class="p-5 border-b border-slate-700">
            <div class="font-bold text-lg">🏛️ لوحة الإدارة</div>
            ${user?`<div class="text-xs text-slate-400 mt-1">${escapeHtml(user.name)} · ${user.role==='admin'?'مدير':'موظف'}</div>`:''}
        </div>
        <nav class="flex-1 p-4 space-y-1 overflow-y-auto">
            ${links.map(l=>`
            <a href="#" onclick="navigateTo('${l.page}');return false;"
               class="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${active===l.key?'bg-primary text-white':'hover:bg-slate-700 text-slate-300'}">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="${l.icon}"/></svg>
                ${l.label}
            </a>`).join('')}
        </nav>
        <div class="p-4 border-t border-slate-700">
            <a href="/" class="block text-center text-xs text-slate-500 hover:text-slate-300 mb-2">← الموقع الرئيسي</a>
            <button onclick="logout()" class="w-full py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 transition-colors text-sm font-medium">تسجيل الخروج</button>
        </div>
    </aside>`;
}

function requireAdminPage() {
    if (!Store.data.currentUser) { window.location.href='/dashboard.php'; return false; }
    return true;
}

// ==========================================
// ADMIN DASHBOARD
// ==========================================
async function renderAdminDashboard() {
    if (!requireAdminPage()) return '';
    const [stats, complaints] = await Promise.all([Store.getStats(), Store.getComplaints()]);
    const recent = complaints.slice(0,5);
    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('dashboard')}
        <main class="flex-1 p-6 overflow-auto">
            <h1 class="text-2xl font-bold mb-6">لوحة التحكم</h1>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                ${[
                    {val:stats.total,             label:'إجمالي الشكاوى', color:'#0d9488', bg:'#f0fdfa'},
                    {val:stats.open,              label:'مفتوحة',          color:'#f59e0b', bg:'#fffbeb'},
                    {val:stats.closed,            label:'تم الحل',         color:'#10b981', bg:'#f0fdf4'},
                    {val:(stats.avgTime||0)+' يوم',label:'متوسط الحل',    color:'#3b82f6', bg:'#eff6ff'},
                ].map(s=>`
                <div class="rounded-2xl p-6 shadow-sm" style="background:${s.bg}">
                    <div class="text-3xl font-bold mb-1" style="color:${s.color}">${s.val}</div>
                    <div class="text-muted text-sm">${s.label}</div>
                </div>`).join('')}
            </div>
            <div class="bg-white rounded-2xl shadow-sm p-6">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="font-bold text-lg">أحدث الشكاوى</h2>
                    <button onclick="navigateTo('admin-complaints')" class="text-primary text-sm hover:underline">عرض الكل</button>
                </div>
                ${recent.length===0?'<p class="text-center text-muted py-8">لا توجد شكاوى</p>':
                `<div class="overflow-x-auto"><table class="w-full text-right text-sm">
                    <thead class="bg-slate-50 border-b"><tr>
                        <th class="p-3">الكود</th><th class="p-3">العنوان</th><th class="p-3">الحالة</th><th class="p-3">التاريخ</th><th class="p-3"></th>
                    </tr></thead>
                    <tbody>${recent.map(c=>`<tr class="border-b hover:bg-slate-50">
                        <td class="p-3 font-mono text-xs text-primary">${escapeHtml(c.complaint_code||c.id)}</td>
                        <td class="p-3 font-medium">${escapeHtml(c.title)}</td>
                        <td class="p-3">${statusBadge(c.status)}</td>
                        <td class="p-3 text-muted text-xs">${formatDate(c.created_at)}</td>
                        <td class="p-3"><button onclick="navigateTo('admin-complaint-detail',{id:${c.id}})" class="text-primary hover:underline text-xs">عرض</button></td>
                    </tr>`).join('')}</tbody>
                </table></div>`}
            </div>
        </main>
    </div>`;
}

// ==========================================
// ADMIN COMPLAINTS — فلترة كاملة + ألوان
// ==========================================
async function renderAdminComplaints(params={}) {
    if (!requireAdminPage()) return '';
    const status   = params.status   || '';
    const category = params.category || '';
    let qs = '';
    if (status)   qs += `&status=${encodeURIComponent(status)}`;
    if (category) qs += `&category=${encodeURIComponent(category)}`;
    const complaints = await Store.getComplaints(qs);

    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('complaints')}
        <main class="flex-1 p-6 overflow-auto">
            <div class="flex flex-wrap justify-between items-center gap-4 mb-6">
                <h1 class="text-2xl font-bold">الشكاوى (${complaints.length})</h1>
                <div class="flex flex-wrap gap-2">
                    <input type="text" id="search-input" placeholder="بحث في العنوان أو الكود..."
                        onkeyup="liveFilter()" class="px-3 py-2 border-2 rounded-xl text-sm input-focus w-44">
                    <select id="filter-status" onchange="applyFilter()" class="px-3 py-2 border-2 rounded-xl text-sm input-focus">
                        <option value="">كل الحالات</option>
                        ${Object.keys(STATUS_CONFIG).map(s=>`<option value="${s}" ${status===s?'selected':''}>${s}</option>`).join('')}
                    </select>
                    <select id="filter-cat" onchange="applyFilter()" class="px-3 py-2 border-2 rounded-xl text-sm input-focus">
                        <option value="">كل الفئات</option>
                        ${Object.keys(CATEGORY_CONFIG).map(c=>`<option value="${c}" ${category===c?'selected':''}>${c}</option>`).join('')}
                    </select>
                </div>
            </div>

            <!-- ألوان الحالات — Legend -->
            <div class="bg-white rounded-xl p-4 mb-4 flex flex-wrap gap-2">
                ${Object.entries(STATUS_CONFIG).map(([s,cfg])=>`
                <div class="flex items-center gap-1.5 cursor-pointer" onclick="document.getElementById('filter-status').value='${s}';applyFilter()">
                    <div class="w-3 h-3 rounded-full" style="background:${cfg.color}"></div>
                    <span class="text-xs text-muted hover:text-secondary">${s}</span>
                </div>`).join('')}
            </div>

            <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-right text-sm" id="complaints-table">
                        <thead class="bg-slate-50 border-b"><tr>
                            <th class="p-4">الكود</th><th class="p-4">العنوان</th><th class="p-4">الفئة</th>
                            <th class="p-4">الحالة</th><th class="p-4">الأولوية</th><th class="p-4">التاريخ</th><th class="p-4"></th>
                        </tr></thead>
                        <tbody id="complaints-body">
                            ${renderComplaintsRows(complaints)}
                        </tbody>
                    </table>
                </div>
                ${complaints.length===0?'<p class="text-center text-muted py-12">لا توجد شكاوى بهذه المعايير</p>':''}
            </div>
        </main>
    </div>`;
}

function renderComplaintsRows(complaints) {
    return complaints.map(c=>{
        const catCfg = CATEGORY_CONFIG[c.category]||CATEGORY_CONFIG['أخرى'];
        return `<tr class="border-b hover:bg-slate-50 complaint-row"
            data-text="${escapeHtml(c.title).toLowerCase()} ${escapeHtml(c.complaint_code||'').toLowerCase()}"
            style="border-right: 4px solid ${STATUS_CONFIG[c.status]?.color||'#e2e8f0'}">
            <td class="p-4 font-mono text-xs text-primary font-bold">${escapeHtml(c.complaint_code||c.id)}</td>
            <td class="p-4 font-medium max-w-xs"><div class="truncate">${escapeHtml(c.title)}</div></td>
            <td class="p-4"><span class="flex items-center gap-1 text-xs">${catCfg.icon} ${c.category}</span></td>
            <td class="p-4">${statusBadge(c.status)}</td>
            <td class="p-4"><span class="text-xs priority-${priorityClass(c.priority)} px-2 py-0.5 rounded-full">${c.priority||'متوسط'}</span></td>
            <td class="p-4 text-muted text-xs">${formatDate(c.created_at)}</td>
            <td class="p-4"><button onclick="navigateTo('admin-complaint-detail',{id:${c.id}})" class="text-primary hover:underline text-xs font-medium">عرض</button></td>
        </tr>`;
    }).join('');
}

function liveFilter() {
    const q = document.getElementById('search-input')?.value.toLowerCase()||'';
    document.querySelectorAll('.complaint-row').forEach(row=>{
        row.style.display = row.dataset.text.includes(q) ? '' : 'none';
    });
}

function applyFilter() {
    const status = document.getElementById('filter-status')?.value||'';
    const cat    = document.getElementById('filter-cat')?.value||'';
    navigateTo('admin-complaints',{status,category:cat});
}

// ==========================================
// ADMIN COMPLAINT DETAIL
// ==========================================
async function renderAdminComplaintDetail(id) {
    if (!requireAdminPage()) return '';
    Store.invalidateCache('track_'+id);
    const res = await Store.getTrackData(id);
    if (!res.success) return `<div class="p-8 text-center text-muted">الشكوى غير موجودة</div>`;
    const c=res.complaint; const history=res.history||[]; const comments=res.comments||[];
    const catCfg=CATEGORY_CONFIG[c.category]||CATEGORY_CONFIG['أخرى'];

    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('complaints')}
        <main class="flex-1 p-6 overflow-auto">
            <button onclick="navigateTo('admin-complaints')" class="flex items-center gap-2 text-muted hover:text-secondary mb-6">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                العودة للشكاوى
            </button>
            <div class="grid lg:grid-cols-3 gap-6">
                <div class="lg:col-span-2 space-y-6">
                    <div class="bg-white rounded-2xl shadow-sm p-6" style="border-top:4px solid ${STATUS_CONFIG[c.status]?.color||'#0d9488'}">
                        <div class="flex flex-wrap justify-between items-start gap-3 mb-4">
                            <div>
                                <div class="flex items-center gap-2 mb-1">
                                    <span class="text-xl">${catCfg.icon}</span>
                                    <span class="font-mono text-sm font-bold text-primary">${escapeHtml(c.complaint_code||c.id)}</span>
                                </div>
                                <h1 class="text-xl font-bold">${escapeHtml(c.title)}</h1>
                                <p class="text-sm text-muted mt-1">${c.category} · ${formatDate(c.created_at)}</p>
                            </div>
                            ${statusBadge(c.status)}
                        </div>
                        <p class="text-slate-600 bg-slate-50 rounded-xl p-4 leading-relaxed">${escapeHtml(c.description)}</p>
                        ${c.address?`<p class="text-sm text-muted mt-3">📍 ${escapeHtml(c.address)}</p>`:''}
                    </div>

                    <!-- الردود -->
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <h3 class="font-bold mb-4">الردود (${comments.length})</h3>
                        <div class="space-y-3 mb-4 max-h-80 overflow-y-auto">
                            ${comments.length===0?'<p class="text-muted text-sm py-4 text-center">لا توجد ردود بعد</p>':
                            comments.map(x=>`
                            <div class="flex gap-3 ${x.user_type==='customer'?'flex-row-reverse':''}">
                                <div class="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-sm
                                    ${x.user_type==='admin'?'bg-primary/10 text-primary':x.user_type==='agent'?'bg-blue-100 text-blue-600':'bg-slate-100 text-muted'}">
                                    ${x.user_type==='admin'?'🏛️':x.user_type==='agent'?'👤':'🙋'}
                                </div>
                                <div class="flex-1">
                                    <div class="text-xs text-muted mb-1">
                                        ${x.user_type==='admin'?'الإدارة':x.user_type==='agent'?'الموظف':'المواطن'} · ${formatDate(x.created_at)}
                                    </div>
                                    <div class="bg-slate-50 rounded-xl p-3 text-sm">${escapeHtml(x.message)}</div>
                                    ${(x.file_path&&typeof x.file_path==='string')?renderAttachment(x.file_path):''}
                                </div>
                            </div>`).join('')}
                        </div>
                        <div class="border-t pt-4">
                            <textarea id="admin-comment" class="w-full px-4 py-3 border-2 rounded-xl resize-none mb-3 input-focus text-sm" rows="2" placeholder="اكتب رداً للمواطن..."></textarea>
                            <button onclick="submitAdminComment(${c.id})" class="btn-primary px-6 py-2.5 rounded-xl text-sm font-medium">إرسال الرد</button>
                        </div>
                    </div>
                </div>

                <div class="space-y-6">
                    <!-- بيانات المُشتكي -->
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <h3 class="font-bold mb-4">بيانات المُشتكي</h3>
                        <div class="space-y-2 text-sm">
                            <div class="flex justify-between"><span class="text-muted">الاسم</span><span class="font-medium">${c.is_anonymous?'🎭 مجهول':escapeHtml(c.name)}</span></div>
                            <div class="flex justify-between"><span class="text-muted">الهاتف</span><span>${c.phone_masked||c.phone}</span></div>
                            ${c.email?`<div class="flex justify-between"><span class="text-muted">البريد</span><span class="text-xs">${escapeHtml(c.email)}</span></div>`:''}
                            <div class="flex justify-between"><span class="text-muted">الأولوية</span><span class="priority-${priorityClass(c.priority)} text-xs px-2 py-0.5 rounded-full">${c.priority||'متوسط'}</span></div>
                        </div>
                    </div>

                    <!-- تغيير الحالة -->
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <h3 class="font-bold mb-4">تغيير الحالة</h3>
                        <select id="status-select" class="w-full px-3 py-2.5 border-2 rounded-xl input-focus text-sm mb-3" onchange="updateAdminStatus(${c.id})">
                            ${Object.keys(STATUS_CONFIG).map(s=>`<option value="${s}" ${c.status===s?'selected':''}>${s}</option>`).join('')}
                        </select>
                    </div>

                    <!-- سجل الحالات -->
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <h3 class="font-bold mb-4">سجل الحالات</h3>
                        <div class="space-y-3">
                            ${history.map((h,i)=>{
                                const cfg=STATUS_CONFIG[h.status]||STATUS_CONFIG['تم الاستلام'];
                                return `<div class="timeline-item ${i>0?'opacity-60':''}">
                                    <div class="timeline-dot" style="background:${cfg.color}"></div>
                                    <div>
                                        <span class="text-sm font-medium" style="color:${cfg.color}">${h.status}</span>
                                        <div class="text-xs text-muted">${formatDate(h.timestamp)}</div>
                                    </div>
                                </div>`;
                            }).join('')}
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>`;
}

async function updateAdminStatus(id) {
    const s = document.getElementById('status-select')?.value;
    if (!s) return;
    const r = await Store.updateComplaint(id,{status:s});
    if (r?.success) { showNotification('تم تحديث الحالة','success'); Store.invalidateCache('track_'+id); navigateTo('admin-complaint-detail',{id}); }
    else showNotification('فشل التحديث','error');
}

async function submitAdminComment(id) {
    const m = document.getElementById('admin-comment')?.value.trim();
    if (!m) return showNotification('اكتب رداً أولاً','error');
    const r = await Store.addComment(id,m);
    if (r?.success) { showNotification('تم إرسال الرد','success'); Store.invalidateCache('track_'+id); navigateTo('admin-complaint-detail',{id}); }
    else showNotification('فشل الإرسال','error');
}

// ==========================================
// ADMIN USERS — إضافة/حذف مستخدمين
// ==========================================
async function renderAdminUsers() {
    if (!requireAdminPage()) return '';
    const users = await Store.getUsers();
    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('users')}
        <main class="flex-1 p-6 overflow-auto">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold">المستخدمين (${users.length})</h1>
                <button onclick="showAddUserModal()" class="btn-primary px-5 py-2.5 rounded-xl font-medium text-sm">+ إضافة مستخدم</button>
            </div>
            <div class="bg-white rounded-2xl shadow-sm overflow-hidden mb-6">
                <div class="overflow-x-auto">
                    <table class="w-full text-right text-sm">
                        <thead class="bg-slate-50 border-b"><tr>
                            <th class="p-4">الاسم</th><th class="p-4">البريد</th><th class="p-4">الهاتف</th><th class="p-4">الدور</th><th class="p-4">تاريخ الإضافة</th><th class="p-4"></th>
                        </tr></thead>
                        <tbody>
                            ${users.map(u=>`
                            <tr class="border-b hover:bg-slate-50">
                                <td class="p-4 font-medium">${escapeHtml(u.name)}</td>
                                <td class="p-4 text-muted">${escapeHtml(u.email)}</td>
                                <td class="p-4 text-muted">${u.phone||'—'}</td>
                                <td class="p-4">
                                    <span class="px-2 py-1 rounded-full text-xs font-medium ${u.role==='admin'?'bg-primary/10 text-primary':'bg-blue-50 text-blue-600'}">
                                        ${u.role==='admin'?'🔑 مدير':'👤 موظف'}
                                    </span>
                                </td>
                                <td class="p-4 text-muted text-xs">${formatDate(u.created_at)}</td>
                                <td class="p-4">
                                    ${u.id!==Store.data.currentUser?.id?`
                                    <button onclick="confirmDeleteUser(${u.id},'${escapeHtml(u.name)}')" class="text-danger hover:underline text-xs">حذف</button>`:'<span class="text-xs text-muted">أنت</span>'}
                                </td>
                            </tr>`).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Modal إضافة مستخدم -->
    <div id="add-user-modal" class="fixed inset-0 z-50 hidden items-center justify-center" style="background:rgba(15,23,42,0.7);backdrop-filter:blur(4px)">
        <div class="bg-white rounded-2xl shadow-xl p-6 w-full max-w-md mx-4">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold">إضافة مستخدم جديد</h2>
                <button onclick="hideAddUserModal()" class="text-muted hover:text-secondary text-xl">✕</button>
            </div>
            <div class="space-y-4">
                <div><label class="block text-sm font-medium mb-1">الاسم <span class="text-danger">*</span></label>
                    <input type="text" id="new-name" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus" placeholder="محمد أحمد"></div>
                <div><label class="block text-sm font-medium mb-1">البريد الإلكتروني <span class="text-danger">*</span></label>
                    <input type="email" id="new-email" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus" placeholder="user@example.com"></div>
                <div><label class="block text-sm font-medium mb-1">كلمة المرور <span class="text-danger">*</span></label>
                    <input type="password" id="new-password" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus" placeholder="8 أحرف على الأقل"></div>
                <div><label class="block text-sm font-medium mb-1">رقم الهاتف</label>
                    <input type="tel" id="new-phone" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus" placeholder="01012345678"></div>
                <div><label class="block text-sm font-medium mb-1">الدور</label>
                    <select id="new-role" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus">
                        <option value="agent">موظف — يتابع ويرد على الشكاوى</option>
                        <option value="admin">مدير — صلاحيات كاملة</option>
                    </select></div>
            </div>
            <div class="flex gap-3 mt-6">
                <button onclick="hideAddUserModal()" class="flex-1 px-4 py-2.5 rounded-xl border-2 border-slate-200 hover:bg-slate-50">إلغاء</button>
                <button onclick="handleAddUser()" class="flex-1 btn-primary px-4 py-2.5 rounded-xl font-medium">إضافة</button>
            </div>
        </div>
    </div>`;
}

function showAddUserModal() { const m=document.getElementById('add-user-modal'); if(m){m.classList.remove('hidden');m.classList.add('flex');} }
function hideAddUserModal() { const m=document.getElementById('add-user-modal'); if(m){m.classList.add('hidden');m.classList.remove('flex');} }

async function handleAddUser() {
    const data = {
        name:     document.getElementById('new-name')?.value.trim(),
        email:    document.getElementById('new-email')?.value.trim(),
        password: document.getElementById('new-password')?.value,
        phone:    document.getElementById('new-phone')?.value.trim(),
        role:     document.getElementById('new-role')?.value,
    };
    if (!data.name||!data.email||!data.password) return showNotification('أكمل الحقول المطلوبة','error');
    if (data.password.length<8) return showNotification('كلمة المرور 8 أحرف على الأقل','error');
    const r = await Store.addUser(data);
    if (r.success) { showNotification('تمت الإضافة','success'); hideAddUserModal(); navigateTo('admin-users'); }
    else showNotification(r.message||'فشل الإضافة','error');
}

async function confirmDeleteUser(id, name) {
    if (!confirm(`هل تريد حذف المستخدم "${name}"؟ هذا الإجراء لا يمكن التراجع عنه.`)) return;
    const r = await Store.deleteUser(id);
    if (r.success) { showNotification('تم الحذف','success'); navigateTo('admin-users'); }
    else showNotification(r.message||'فشل الحذف','error');
}

// ==========================================
// ADMIN REPORTS — تقرير شهري
// ==========================================
async function renderAdminReports() {
    if (!requireAdminPage()) return '';
    const currentMonth = new Date().toISOString().substring(0,7);
    const selectedMonth = currentMonth;
    const report = await Store.getMonthlyReport(selectedMonth);

    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('reports')}
        <main class="flex-1 p-6 overflow-auto">
            <div class="flex flex-wrap justify-between items-center gap-4 mb-6">
                <h1 class="text-2xl font-bold">التقارير الشهرية</h1>
                <div class="flex items-center gap-2">
                    <label class="text-sm font-medium">الشهر:</label>
                    <input type="month" id="report-month" value="${selectedMonth}"
                        onchange="loadMonthReport(this.value)"
                        class="px-3 py-2 border-2 rounded-xl text-sm input-focus">
                </div>
            </div>
            <div id="report-content">
                ${renderReportContent(report)}
            </div>
        </main>
    </div>`;
}

function renderReportContent(report) {
    if (!report.success) return '<p class="text-muted text-center py-12">لا توجد بيانات لهذا الشهر</p>';
    const total   = report.total || 1;
    const byStatus = report.by_status || {};
    const byCat    = report.by_category || {};

    return `
    <!-- ملخص سريع -->
    <div class="grid grid-cols-3 gap-4 mb-6">
        <div class="bg-white rounded-2xl shadow-sm p-6 text-center">
            <div class="text-3xl font-bold text-primary">${report.total}</div>
            <div class="text-muted text-sm">إجمالي الشهر</div>
        </div>
        <div class="bg-white rounded-2xl shadow-sm p-6 text-center">
            <div class="text-3xl font-bold text-success">${report.solved}</div>
            <div class="text-muted text-sm">تم حلها</div>
        </div>
        <div class="bg-white rounded-2xl shadow-sm p-6 text-center">
            <div class="text-3xl font-bold text-warning">${Math.round((report.solved/total)*100)}%</div>
            <div class="text-muted text-sm">نسبة الحل</div>
        </div>
    </div>

    <div class="grid md:grid-cols-2 gap-6 mb-6">
        <!-- توزيع حسب الحالة -->
        <div class="bg-white rounded-2xl shadow-sm p-6">
            <h2 class="font-bold text-lg mb-4">توزيع حسب الحالة</h2>
            <div class="space-y-3">
                ${Object.entries(byStatus).length===0?'<p class="text-muted text-sm">لا توجد بيانات</p>':
                Object.entries(byStatus).map(([s,count])=>{
                    const cfg=STATUS_CONFIG[s]||{color:'#6b7280'};
                    const pct=Math.round(count/total*100);
                    return `<div>
                        <div class="flex justify-between items-center mb-1">
                            <span class="text-sm">${s}</span>
                            <span class="text-sm font-bold">${count} (${pct}%)</span>
                        </div>
                        <div class="w-full bg-slate-100 rounded-full h-2">
                            <div class="h-2 rounded-full transition-all" style="width:${pct}%;background:${cfg.color}"></div>
                        </div>
                    </div>`;
                }).join('')}
            </div>
        </div>

        <!-- توزيع حسب الفئة -->
        <div class="bg-white rounded-2xl shadow-sm p-6">
            <h2 class="font-bold text-lg mb-4">توزيع حسب الفئة</h2>
            <div class="space-y-3">
                ${Object.entries(byCat).length===0?'<p class="text-muted text-sm">لا توجد بيانات</p>':
                Object.entries(byCat).map(([cat,count])=>{
                    const cfg=CATEGORY_CONFIG[cat]||{icon:'📋',color:'#6b7280'};
                    const pct=Math.round(count/total*100);
                    return `<div class="flex items-center gap-3">
                        <span class="text-xl w-7 text-center flex-shrink-0">${cfg.icon}</span>
                        <div class="flex-1">
                            <div class="flex justify-between mb-1">
                                <span class="text-sm">${cat}</span>
                                <span class="text-sm font-bold">${count}</span>
                            </div>
                            <div class="w-full bg-slate-100 rounded-full h-2">
                                <div class="h-2 rounded-full" style="width:${pct}%;background:${cfg.color}"></div>
                            </div>
                        </div>
                    </div>`;
                }).join('')}
            </div>
        </div>
    </div>

    <!-- جدول الشكاوى التفصيلي -->
    <div class="bg-white rounded-2xl shadow-sm p-6">
        <h2 class="font-bold text-lg mb-4">تفاصيل شكاوى الشهر (${report.complaints?.length||0})</h2>
        ${!report.complaints||report.complaints.length===0?'<p class="text-muted text-center py-6">لا توجد شكاوى هذا الشهر</p>':
        `<div class="overflow-x-auto">
            <table class="w-full text-right text-sm">
                <thead class="bg-slate-50 border-b"><tr>
                    <th class="p-3">الكود</th><th class="p-3">العنوان</th><th class="p-3">الفئة</th><th class="p-3">الحالة</th><th class="p-3">التاريخ</th><th class="p-3"></th>
                </tr></thead>
                <tbody>
                    ${report.complaints.map(c=>`
                    <tr class="border-b hover:bg-slate-50" style="border-right:3px solid ${STATUS_CONFIG[c.status]?.color||'#e2e8f0'}">
                        <td class="p-3 font-mono text-xs text-primary font-bold">${escapeHtml(c.complaint_code||c.id)}</td>
                        <td class="p-3 font-medium max-w-xs"><div class="truncate">${escapeHtml(c.title)}</div></td>
                        <td class="p-3 text-xs">${CATEGORY_CONFIG[c.category]?.icon||'📋'} ${c.category}</td>
                        <td class="p-3">${statusBadge(c.status)}</td>
                        <td class="p-3 text-muted text-xs">${formatDate(c.created_at)}</td>
                        <td class="p-3"><button onclick="navigateTo('admin-complaint-detail',{id:${c.id}})" class="text-primary hover:underline text-xs">عرض</button></td>
                    </tr>`).join('')}
                </tbody>
            </table>
        </div>`}
    </div>`;
}

async function loadMonthReport(month) {
    const content = document.getElementById('report-content');
    if (content) content.innerHTML = '<div class="flex justify-center py-12"><div class="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div></div>';
    const report = await Store.getMonthlyReport(month);
    if (content) content.innerHTML = renderReportContent(report);
}

// ==========================================
// AGENT PANEL
// ==========================================
async function renderAgentPanel() {
    if (!Store.data.currentUser) { window.location.href='/dashboard.php'; return ''; }
    const user = Store.data.currentUser;
    const complaints = await Store.getComplaints('&status=تم الاستلام');
    const open = complaints.filter(c=>!['تم الحل','مغلقة','مرفوضة'].includes(c.status));

    return `
    <div class="flex min-h-screen bg-slate-100">
        <aside class="sidebar fixed lg:static inset-y-0 right-0 w-64 bg-secondary text-white z-40 flex flex-col">
            <div class="p-5 border-b border-slate-700">
                <div class="font-bold">👤 لوحة الموظف</div>
                <div class="text-xs text-slate-400 mt-1">${escapeHtml(user.name)}</div>
            </div>
            <div class="flex-1 p-4">
                <a href="#" onclick="navigateTo('agent');return false;" class="flex items-center gap-2 px-4 py-3 rounded-xl bg-primary text-white text-sm">الشكاوى المفتوحة</a>
            </div>
            <div class="p-4 border-t border-slate-700">
                <a href="/" class="block text-center text-xs text-slate-500 hover:text-slate-300 mb-2">← الموقع الرئيسي</a>
                <button onclick="logout()" class="w-full py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-sm">تسجيل الخروج</button>
            </div>
        </aside>
        <main class="flex-1 p-6 overflow-auto">
            <h1 class="text-2xl font-bold mb-2">الشكاوى المفتوحة</h1>
            <p class="text-muted text-sm mb-6">الشكاوى التي تحتاج متابعة (${open.length})</p>
            ${open.length===0?`<div class="bg-white rounded-2xl p-12 text-center"><div class="text-5xl mb-4">✅</div><h2 class="font-bold text-lg">لا توجد شكاوى مفتوحة</h2></div>`:
            `<div class="grid gap-4">${open.map(c=>`
            <div class="bg-white rounded-2xl shadow-sm p-5 flex flex-wrap justify-between items-start gap-4" style="border-right:4px solid ${STATUS_CONFIG[c.status]?.color||'#0d9488'}">
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 mb-1">
                        <span class="font-mono text-xs text-primary font-bold">${escapeHtml(c.complaint_code||c.id)}</span>
                        ${statusBadge(c.status)}
                        <span class="text-xs priority-${priorityClass(c.priority)} px-2 py-0.5 rounded-full">${c.priority||'متوسط'}</span>
                    </div>
                    <h3 class="font-bold truncate">${escapeHtml(c.title)}</h3>
                    <p class="text-sm text-muted mt-1">${CATEGORY_CONFIG[c.category]?.icon||'📋'} ${c.category} · ${formatDate(c.created_at)}</p>
                </div>
                <button onclick="navigateTo('admin-complaint-detail',{id:${c.id}})" class="btn-primary px-4 py-2 rounded-lg text-sm font-medium flex-shrink-0">عرض / رد</button>
            </div>`).join('')}</div>`}
        </main>
    </div>`;
}

// ==========================================
// INIT
// ==========================================
// تحقق لو المستخدم جاء من dashboard.php
if (window.location.hash === '#dashboard' && Store.data.currentUser) {
    window.history.replaceState(null, '', '/');
    navigateTo(Store.data.currentUser.role === 'admin' ? 'admin' : 'agent');
} else {
    renderPage();
}
