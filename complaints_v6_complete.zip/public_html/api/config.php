<?php
// ============================================================
// api/config.php — النسخة النهائية الآمنة
// ============================================================

// منع أي output قبل JSON — Notices, Warnings, BOM
ob_start();
error_reporting(0);
ini_set('display_errors', 0);

// CORS — غيّر الدومين لدومين موقعك الفعلي
$allowed = 'https://hadayek-elqobba.com';
$origin  = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin === $allowed) {
    header("Access-Control-Allow-Origin: $allowed");
} else {
    // السماح بنفس الـ origin دائماً (same-origin requests)
    header("Access-Control-Allow-Origin: " . ($_SERVER['HTTP_HOST'] ?? '*'));
}
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// تحميل credentials من خارج public_html
// dirname(__DIR__, 2): api/ → public_html/ → home/u629093312/
$configPath = dirname(__DIR__, 2) . '/private/db.config.php';

if (!file_exists($configPath)) {
    http_response_code(500);
    ob_clean();
    echo json_encode(["success" => false, "message" => "Server configuration error"]);
    exit;
}
require_once $configPath;

// اتصال PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    ob_clean();
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

// تنظيف المدخلات
function cleanInput($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// دالة مساعدة لإرسال JSON نظيف
function sendJson($data, $code = 200) {
    http_response_code($code);
    ob_clean();
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// بدء الجلسة مرة واحدة فقط
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// التحقق من صلاحية Admin
function requireAdmin() {
    if (empty($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
        sendJson(["success" => false, "message" => "غير مصرح"], 403);
    }
}

// التحقق من تسجيل الدخول (Admin أو Agent)
function requireAuth() {
    if (empty($_SESSION['user_id'])) {
        sendJson(["success" => false, "message" => "يجب تسجيل الدخول"], 401);
    }
}
?>
