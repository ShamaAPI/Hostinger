<?php
// ============================================================
// api/submit.php — توليد رقم شكوى حسب النوع + رقم عشوائي
// ============================================================
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(["success" => false, "message" => "Method Not Allowed"], 405);
}

$data = json_decode(file_get_contents("php://input"), true) ?? [];

// Validation
$required = ['category', 'title', 'description', 'name', 'phone'];
foreach ($required as $field) {
    if (empty(trim($data[$field] ?? ''))) {
        sendJson(["success" => false, "message" => "الحقل '$field' مطلوب"], 400);
    }
}

$phone = preg_replace('/\s+/', '', $data['phone']);
if (!preg_match('/^01[0125][0-9]{8}$/', $phone)) {
    sendJson(["success" => false, "message" => "رقم الهاتف غير صحيح. مثال: 01012345678"], 400);
}

if (mb_strlen(trim($data['title'])) < 5) {
    sendJson(["success" => false, "message" => "عنوان الشكوى قصير جداً (5 أحرف على الأقل)"], 400);
}
if (mb_strlen(trim($data['description'])) < 20) {
    sendJson(["success" => false, "message" => "وصف الشكوى قصير جداً (20 حرف على الأقل)"], 400);
}

$allowedCats = ['نظافة', 'كهرباء', 'مياه', 'طرق', 'فساد', 'أخرى'];
if (!in_array($data['category'], $allowedCats)) {
    sendJson(["success" => false, "message" => "فئة غير صحيحة"], 400);
}

$email = null;
if (!empty($data['email'])) {
    $email = filter_var($data['email'], FILTER_VALIDATE_EMAIL);
    if (!$email) sendJson(["success" => false, "message" => "البريد الإلكتروني غير صحيح"], 400);
}

$priority = in_array($data['priority'] ?? '', ['منخفض','متوسط','مرتفع','عاجل'])
    ? $data['priority'] : 'متوسط';

// --- توليد رقم الشكوى حسب النوع ---
// بادئة حسب الفئة + رقم عشوائي 6 أرقام غير متسلسل
$prefixMap = [
    'نظافة'  => 'CLN',
    'كهرباء' => 'ELC',
    'مياه'   => 'WTR',
    'طرق'    => 'RDW',
    'فساد'   => 'CRP',
    'أخرى'   => 'GEN',
];
$prefix = $prefixMap[$data['category']] ?? 'GEN';
// رقم عشوائي 6 أرقام — نتأكد إنه غير موجود في قاعدة البيانات
do {
    $rand = str_pad(random_int(100000, 999999), 6, '0', STR_PAD_LEFT);
    $complaintCode = $prefix . '-' . $rand;
    $check = $pdo->prepare("SELECT id FROM complaints WHERE complaint_code = ?");
    $check->execute([$complaintCode]);
} while ($check->fetch());

try {
    $stmt = $pdo->prepare("
        INSERT INTO complaints
        (complaint_code, title, description, category, priority, name, phone, email,
         is_anonymous, address, latitude, longitude, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'تم الاستلام', NOW())
    ");
    $stmt->execute([
        $complaintCode,
        cleanInput($data['title']),
        cleanInput($data['description']),
        cleanInput($data['category']),
        $priority,
        cleanInput($data['name']),
        $phone,
        $email,
        !empty($data['isAnonymous']) ? 1 : 0,
        cleanInput($data['address'] ?? ''),
        is_numeric($data['latitude']  ?? null) ? $data['latitude']  : null,
        is_numeric($data['longitude'] ?? null) ? $data['longitude'] : null,
    ]);

    $dbId = (int)$pdo->lastInsertId();

    $pdo->prepare("INSERT INTO status_history (complaint_id, status, timestamp) VALUES (?, 'تم الاستلام', NOW())")
        ->execute([$dbId]);

    sendJson([
        "success"        => true,
        "message"        => "تم تقديم الشكوى بنجاح",
        "complaint_id"   => $dbId,
        "complaint_code" => $complaintCode,
    ]);

} catch (PDOException $e) {
    sendJson(["success" => false, "message" => "حدث خطأ أثناء الحفظ"], 500);
}
?>
