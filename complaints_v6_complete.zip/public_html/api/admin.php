<?php
require 'config.php';

function getJsonInput() {
    return json_decode(file_get_contents("php://input"), true) ?? [];
}

define('ALLOWED_MIME', ['image/jpeg','image/png','image/gif','image/webp','application/pdf']);
define('MAX_FILE_SIZE', 5 * 1024 * 1024);

function handleFileUpload($fileKey = 'file') {
    if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) return null;
    $file = $_FILES[$fileKey];
    if ($file['size'] > MAX_FILE_SIZE) sendJson(["success"=>false,"message"=>"حجم الملف يتجاوز 5MB"], 400);
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    if (!in_array($mime, ALLOWED_MIME)) sendJson(["success"=>false,"message"=>"نوع الملف غير مسموح"], 400);
    $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $safeName = time() . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $uploadDir = '../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    if (move_uploaded_file($file['tmp_name'], $uploadDir . $safeName)) return 'uploads/' . $safeName;
    return null;
}

$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    requireAdmin();
    switch ($action) {
        case 'stats':          getStats($pdo);         break;
        case 'list':           listComplaints($pdo);   break;
        case 'list_users':     listUsers($pdo);        break;
        case 'monthly_report': monthlyReport($pdo);    break;
        default: sendJson(["success"=>false,"message"=>"Invalid action"]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($action) {
        case 'update_status':
        case 'add_user':
        case 'delete_user':
            requireAdmin();
            if ($action === 'update_status') updateStatus($pdo);
            elseif ($action === 'add_user')  addUser($pdo);
            else                             deleteUser($pdo);
            break;
        case 'add_comment':
            requireAuth();
            addComment($pdo);
            break;
        case 'add_customer_reply':
            addCustomerReply($pdo);
            break;
        default:
            sendJson(["success"=>false,"message"=>"Invalid action"]);
    }
} else {
    sendJson(["success"=>false,"message"=>"Method Not Allowed"], 405);
}

// ============================================================
function getStats($pdo) {
    try {
        $total      = (int)$pdo->query("SELECT COUNT(*) FROM complaints")->fetchColumn();
        $open       = (int)$pdo->query("SELECT COUNT(*) FROM complaints WHERE status NOT IN ('تم الحل','مغلقة','مرفوضة')")->fetchColumn();
        $closed     = (int)$pdo->query("SELECT COUNT(*) FROM complaints WHERE status IN ('تم الحل','مغلقة')")->fetchColumn();
        $inProgress = (int)$pdo->query("SELECT COUNT(*) FROM complaints WHERE status='جاري التنفيذ'")->fetchColumn();
        $avgRow     = $pdo->query("SELECT ROUND(AVG(TIMESTAMPDIFF(HOUR,created_at,updated_at)/24),1) as avg_days FROM complaints WHERE status IN ('تم الحل','مغلقة') AND updated_at IS NOT NULL")->fetch();
        $avgTime    = $avgRow['avg_days'] ?? 0;
        sendJson(["success"=>true,"stats"=>compact('total','open','closed','inProgress','avgTime')]);
    } catch (PDOException $e) { sendJson(["success"=>false,"message"=>"DB Error"]); }
}

function listComplaints($pdo) {
    try {
        $status   = $_GET['status']   ?? '';
        $category = $_GET['category'] ?? '';
        $search   = $_GET['search']   ?? '';
        $sql = "SELECT * FROM complaints WHERE 1=1";
        $params = [];
        if ($status)   { $sql .= " AND status = ?";   $params[] = $status; }
        if ($category) { $sql .= " AND category = ?"; $params[] = $category; }
        if ($search)   { $sql .= " AND (title LIKE ? OR complaint_code LIKE ? OR phone LIKE ?)";
                         $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }
        $sql .= " ORDER BY created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        sendJson(["success"=>true,"complaints"=>$stmt->fetchAll()]);
    } catch (PDOException $e) { sendJson(["success"=>false]); }
}

function listUsers($pdo) {
    try {
        $users = $pdo->query("SELECT id,name,email,phone,role,created_at FROM users ORDER BY id DESC")->fetchAll();
        sendJson(["success"=>true,"users"=>$users]);
    } catch (PDOException $e) { sendJson(["success"=>false]); }
}

function monthlyReport($pdo) {
    try {
        $month = $_GET['month'] ?? date('Y-m');
        // شكاوى الشهر
        $stmt = $pdo->prepare("SELECT * FROM complaints WHERE DATE_FORMAT(created_at,'%Y-%m') = ? ORDER BY created_at DESC");
        $stmt->execute([$month]);
        $complaints = $stmt->fetchAll();

        // إحصائيات الشهر
        $byStatus = []; $byCat = [];
        foreach ($complaints as $c) {
            $byStatus[$c['status']] = ($byStatus[$c['status']] ?? 0) + 1;
            $byCat[$c['category']]  = ($byCat[$c['category']]  ?? 0) + 1;
        }

        // معدل الحل
        $solvedStmt = $pdo->prepare("SELECT COUNT(*) FROM complaints WHERE DATE_FORMAT(created_at,'%Y-%m')=? AND status IN ('تم الحل','مغلقة')");
        $solvedStmt->execute([$month]);
        $solved = (int)$solvedStmt->fetchColumn();

        // كل مراحل الشكاوى هذا الشهر
        $histStmt = $pdo->prepare("
            SELECT sh.*, c.complaint_code, c.title, c.category
            FROM status_history sh
            JOIN complaints c ON c.id = sh.complaint_id
            WHERE DATE_FORMAT(sh.timestamp,'%Y-%m') = ?
            ORDER BY sh.timestamp DESC
        ");
        $histStmt->execute([$month]);
        $history = $histStmt->fetchAll();

        sendJson([
            "success"     => true,
            "month"       => $month,
            "complaints"  => $complaints,
            "by_status"   => $byStatus,
            "by_category" => $byCat,
            "total"       => count($complaints),
            "solved"      => $solved,
            "history"     => $history,
        ]);
    } catch (PDOException $e) { sendJson(["success"=>false,"message"=>"DB Error"]); }
}

function updateStatus($pdo) {
    $data   = getJsonInput();
    $id     = (int)($data['id'] ?? 0);
    $status = cleanInput($data['status'] ?? '');
    $allowed = ['تم الاستلام','قيد المراجعة','جاري التنفيذ','تم الحل','مغلقة','مرفوضة'];
    if (!$id || !in_array($status, $allowed)) sendJson(["success"=>false,"message"=>"بيانات غير صحيحة"]);
    try {
        $pdo->prepare("UPDATE complaints SET status=?,updated_at=NOW() WHERE id=?")->execute([$status,$id]);
        $pdo->prepare("INSERT INTO status_history (complaint_id,status,changed_by,timestamp) VALUES(?,?,?,NOW())")
            ->execute([$id,$status,$_SESSION['user_id']]);
        sendJson(["success"=>true]);
    } catch (PDOException $e) { sendJson(["success"=>false]); }
}

function addComment($pdo) {
    if (!empty($_POST['complaint_id'])) {
        $complaint_id = (int)$_POST['complaint_id'];
        $message      = cleanInput($_POST['message'] ?? '');
    } else {
        $data         = getJsonInput();
        $complaint_id = (int)($data['complaint_id'] ?? 0);
        $message      = cleanInput($data['message'] ?? '');
    }
    if (!$complaint_id || !$message) sendJson(["success"=>false,"message"=>"بيانات ناقصة"]);
    $file_path = handleFileUpload('file');
    try {
        $pdo->prepare("INSERT INTO comments (complaint_id,user_type,message,file_path,created_at) VALUES(?,'admin',?,?,NOW())")
            ->execute([$complaint_id,$message,$file_path]);
        sendJson(["success"=>true]);
    } catch (PDOException $e) { sendJson(["success"=>false,"message"=>"DB Error"]); }
}

function addCustomerReply($pdo) {
    $complaint_id = (int)($_POST['complaint_id'] ?? 0);
    $message      = cleanInput($_POST['message'] ?? '');
    if (!$complaint_id) sendJson(["success"=>false,"message"=>"رقم الشكوى مطلوب"]);
    $check = $pdo->prepare("SELECT id FROM complaints WHERE id=?");
    $check->execute([$complaint_id]);
    if (!$check->fetch()) sendJson(["success"=>false,"message"=>"الشكوى غير موجودة"]);
    $file_path = handleFileUpload('file');
    try {
        $pdo->prepare("INSERT INTO comments (complaint_id,user_type,message,file_path,created_at) VALUES(?,'customer',?,?,NOW())")
            ->execute([$complaint_id,$message,$file_path]);
        sendJson(["success"=>true]);
    } catch (PDOException $e) { sendJson(["success"=>false,"message"=>"DB Error"]); }
}

function addUser($pdo) {
    $data     = getJsonInput();
    $name     = cleanInput($data['name']  ?? '');
    $email    = filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $password = $data['password'] ?? '';
    $phone    = cleanInput($data['phone'] ?? '');
    $role     = in_array($data['role']??'',['admin','agent']) ? $data['role'] : 'agent';
    if (!$name || !$email || strlen($password)<8) sendJson(["success"=>false,"message"=>"بيانات ناقصة أو كلمة مرور أقل من 8 أحرف"]);
    $check = $pdo->prepare("SELECT id FROM users WHERE email=?");
    $check->execute([$email]);
    if ($check->fetch()) sendJson(["success"=>false,"message"=>"البريد مسجل مسبقاً"]);
    try {
        $pdo->prepare("INSERT INTO users (name,email,password,phone,role) VALUES(?,?,?,?,?)")
            ->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),$phone,$role]);
        sendJson(["success"=>true]);
    } catch (PDOException $e) { sendJson(["success"=>false,"message"=>"DB Error"]); }
}

function deleteUser($pdo) {
    $data = getJsonInput();
    $id   = (int)($data['id'] ?? 0);
    if (!$id) sendJson(["success"=>false,"message"=>"ID مطلوب"]);
    // منع حذف نفسك
    if ($id === (int)$_SESSION['user_id']) sendJson(["success"=>false,"message"=>"لا يمكنك حذف حسابك"]);
    try {
        $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
        sendJson(["success"=>true]);
    } catch (PDOException $e) { sendJson(["success"=>false,"message"=>"DB Error"]); }
}
?>
