<?php
require 'config.php';

$query = trim($_GET['query'] ?? '');
if (!$query) {
    sendJson(["success" => false, "message" => "يرجى إدخال رقم الشكوى أو الهاتف"]);
}

try {
    // البحث بـ complaint_code أو رقم DB أو الهاتف
    $stmt = $pdo->prepare("
        SELECT * FROM complaints
        WHERE complaint_code = ? OR id = ? OR phone = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$query, is_numeric($query) ? $query : 0, $query]);
    $complaints = $stmt->fetchAll();

    if (empty($complaints)) {
        sendJson(["success" => false, "message" => "لم يتم العثور على نتائج"]);
    }

    $main = $complaints[0];
    $cid  = $main['id'];

    $histStmt = $pdo->prepare("SELECT * FROM status_history WHERE complaint_id = ? ORDER BY timestamp ASC");
    $histStmt->execute([$cid]);
    $history = $histStmt->fetchAll();

    $comStmt = $pdo->prepare("SELECT * FROM comments WHERE complaint_id = ? ORDER BY created_at ASC");
    $comStmt->execute([$cid]);
    $comments = $comStmt->fetchAll();

    // إخفاء جزء من الهاتف
    foreach ($complaints as &$c) {
        if (!empty($c['phone'])) {
            $c['phone_masked'] = substr($c['phone'], 0, 4) . '****' . substr($c['phone'], -3);
        }
    }

    sendJson([
        "success"   => true,
        "complaint" => $main,
        "history"   => $history,
        "comments"  => $comments,
        "related"   => array_slice($complaints, 1),
    ]);

} catch (PDOException $e) {
    sendJson(["success" => false, "message" => "خطأ في الخادم"], 500);
}
?>
