// ============================================================
// app.js — v10 الكاملة
// ============================================================

// ==========================================
// CONFIG
// ==========================================
const DISTRICTS = ['ابوحشيش','دير الملاك','مكاوى','المليحة','منشية الصدر','مصر والسودان','سكة الوايلى','الشيخ غراب','كوبرى القبة','الوايلى'];

const STATUS_CONFIG = {
    'تم الاستلام':   { cls:'status-received',    color:'#3b82f6', bg:'#dbeafe' },
    'قيد المراجعة': { cls:'status-reviewing',   color:'#f59e0b', bg:'#fef3c7' },
    'جاري التنفيذ': { cls:'status-in-progress', color:'#10b981', bg:'#d1fae5' },
    'تم الحل':      { cls:'status-resolved',    color:'#059669', bg:'#dcfce7' },
    'مغلقة':        { cls:'status-closed',      color:'#6b7280', bg:'#f1f5f9' },
    'مرفوضة':       { cls:'status-rejected',    color:'#ef4444', bg:'#fee2e2' },
};

const CATEGORY_CONFIG = {
    'نظافة':  { prefix:'CLN', icon:'🗑️',  color:'#84cc16' },
    'كهرباء': { prefix:'ELC', icon:'⚡',  color:'#f59e0b' },
    'مياه':   { prefix:'WTR', icon:'💧',  color:'#3b82f6' },
    'طرق':    { prefix:'RDW', icon:'🛣️',  color:'#8b5cf6' },
    'فساد':   { prefix:'CRP', icon:'🚨',  color:'#ef4444' },
    'صحة':    { prefix:'HLT', icon:'🏥',  color:'#ec4899' },
    'تعليم':  { prefix:'EDU', icon:'📚',  color:'#06b6d4' },
    'معاشات': { prefix:'PNS', icon:'👴',  color:'#f97316' },
    'تموين':  { prefix:'SUP', icon:'🛒',  color:'#a855f7' },
    'أخرى':   { prefix:'GEN', icon:'📋',  color:'#6b7280' },
};

// ==========================================
// STORE
// ==========================================
const Store = {
    data: { currentUser: null },
    _cache: {},

    async api(endpoint, method='GET', body=null) {
        const opts = { method, headers:{'Content-Type':'application/json'}, credentials:'include' };
        if (body) opts.body = JSON.stringify(body);
        try {
            const res  = await fetch(`api/${endpoint}`, opts);
            if (res.status===401) { navigateTo('login'); return {success:false}; }
            if (res.status===403) { showNotification('غير مصرح','error'); return {success:false}; }
            const txt  = await res.text();
            if (!txt.trim()) return {success:false,message:'استجابة فارغة'};
            const clean = txt.trim().replace(/^\uFEFF/,'');
            if (!clean.startsWith('{')&&!clean.startsWith('[')) { console.error('Non-JSON:',clean.substring(0,200)); return {success:false,message:'خطأ في الخادم'}; }
            return JSON.parse(clean);
        } catch(e) { console.error('API:',e); return {success:false,message:'خطأ في الاتصال'}; }
    },

    init() { /* no auto-restore */ },

    async login(e,p)       { const r=await this.api('login.php','POST',{email:e,password:p}); if(r.success){this.data.currentUser=r.user;} return r.success?r.user:null; },
    logout()                { this.data.currentUser=null; this._cache={}; },
    invalidateCache(k)      { if(k) delete this._cache[k]; else this._cache={}; },

    async getTrackData(q) {
        const k='track_'+q;
        if (this._cache[k]) return this._cache[k];
        const r = await this.api(`track.php?query=${encodeURIComponent(q)}`);
        if (r.success) this._cache[k]=r;
        return r;
    },

    async addComplaint(c)       { return await this.api('submit.php','POST',c); },
    async getStats()             { const r=await this.api('admin.php?action=stats'); return r.success?r.stats:{total:0,complaints:0,requests:0,open:0,closed:0,unread:0}; },
    async getComplaints(qs='')   { const r=await this.api('admin.php?action=list'+qs); return r.complaints||[]; },
    async getUsers()             { const r=await this.api('admin.php?action=list_users'); return r.users||[]; },
    async getNotifications()     { const r=await this.api('admin.php?action=notifications'); return r.notifications||[]; },
    async getMonthlyReport(m)    { return await this.api(`admin.php?action=monthly_report&month=${m}`); },
    async getComplaintDetail(id) {
        if (!id) return {success:false, message:'ID غير موجود'};
        return await this.api(`admin.php?action=get_complaint&id=${parseInt(id)}`);
    },
    async updateComplaint(id,upd){ if(upd.status) return await this.api('admin.php?action=update_status','POST',{id,status:upd.status}); },
    async requestStatusChange(cid,status,reason){ return await this.api('admin.php?action=request_status_change','POST',{complaint_id:cid,status,reason}); },
    async getStatusRequests(){ const r=await this.api('admin.php?action=status_requests'); return r.requests||[]; },
    async approveStatusChange(rid,approve){ return await this.api('admin.php?action=approve_status_change','POST',{request_id:rid,approve}); },
    async assignComplaint(cid,uid){ return await this.api('admin.php?action=assign','POST',{complaint_id:cid,user_id:uid}); },
    async markRead(cid)          { return await this.api('admin.php?action=mark_read','POST',{complaint_id:cid}); },
    async addUser(d)             { return await this.api('admin.php?action=add_user','POST',d); },
    async deleteUser(id)         { return await this.api('admin.php?action=delete_user','POST',{id}); },
};
Store.init();

// ==========================================
// UTILS
// ==========================================
function escapeHtml(s) {
    if (s===null||s===undefined||typeof s==='object') return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
function statusBadge(s) {
    const c=STATUS_CONFIG[s]||STATUS_CONFIG['تم الاستلام'];
    return `<span class="status-badge" style="background:${c.bg};color:${c.color};border:1px solid ${c.color}44">${s}</span>`;
}
function priorityClass(p) { return {'منخفض':'low','متوسط':'medium','مرتفع':'high','عاجل':'urgent'}[p]||'medium'; }
function categoryIcon(c)  { return CATEGORY_CONFIG[c]?.icon||'📋'; }
function formatDate(d)    { if(!d) return ''; return new Date(d).toLocaleDateString('ar-EG',{year:'numeric',month:'long',day:'numeric'}); }
function formatTime(d)    { if(!d) return ''; return new Date(d).toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit'}); }

function showNotification(m,t='info') {
    const c=document.getElementById('notifications'); if(!c) return;
    const d=document.createElement('div');
    d.className=`notification flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-white text-sm ${t==='success'?'bg-success':t==='error'?'bg-danger':'bg-info'}`;
    d.innerHTML=`<span class="font-bold">${{success:'✓',error:'✕',info:'ℹ'}[t]||'ℹ'}</span><span>${escapeHtml(m)}</span>`;
    c.appendChild(d);
    setTimeout(()=>{d.style.opacity='0';d.style.transition='opacity .3s';setTimeout(()=>d.remove(),300);},3500);
}

function toggleMobileMenu() { document.getElementById('mobile-menu')?.classList.toggle('hidden'); }
function closeMobileMenu()  { document.getElementById('mobile-menu')?.classList.add('hidden'); }
document.addEventListener('click',e=>{ const m=document.getElementById('mobile-menu'); if(m&&!m.classList.contains('hidden')&&!e.target.closest('[onclick="toggleMobileMenu()"]')&&!m.contains(e.target)) m.classList.add('hidden'); });
document.addEventListener('change',e=>{ if(e.target.id==='reply-file'){ const s=document.getElementById('file-name'); if(s) s.textContent=e.target.files[0]?.name||'لم يتم اختيار ملف'; }});
function logout() { Store.logout(); showNotification('تم تسجيل الخروج','success'); navigateTo('home'); }

// ==========================================
// ROUTER
// ==========================================
let currentPage='home';
function navigateTo(page,params={}) {
    currentPage=page; window.scrollTo(0,0); closeMobileMenu();
    const nav=document.getElementById('public-nav');
    ['admin','admin-complaints','admin-users','admin-reports','admin-complaint-detail','agent'].includes(page)?nav?.classList.add('hidden'):nav?.classList.remove('hidden');
    renderPage(params);
}

async function renderPage(params={}) {
    const main=document.getElementById('main-content'); if(!main) return;
    const spinner=`<div class="min-h-screen flex flex-col items-center justify-center gap-3"><div class="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div><p class="text-muted text-sm">جاري التحميل...</p></div>`;
    try {
        let html='';
        switch(currentPage) {
            case 'home':                   html=renderHomePage(); break;
            case 'submit':                 html=renderSubmitPage(); setTimeout(()=>initSubmitForm(),0); break;
            case 'track':                  html=renderTrackPage(); break;
            case 'track-result':           main.innerHTML=spinner; html=await renderTrackResultPage(params.id); break;
            case 'login':                  html=renderLoginPage(); break;
            case 'admin':                  main.innerHTML=spinner; html=await renderAdminDashboard(); break;
            case 'admin-complaints':       main.innerHTML=spinner; html=await renderAdminComplaints(params); break;
            case 'admin-complaint-detail': main.innerHTML=spinner; html=await renderAdminComplaintDetail(params.id); break;
            case 'admin-requests':         main.innerHTML=spinner; html=await renderAdminStatusRequests(); break;
            case 'admin-users':            main.innerHTML=spinner; html=await renderAdminUsers(); break;
            case 'admin-reports':          main.innerHTML=spinner; html=await renderAdminReports(); break;
            case 'agent':                  main.innerHTML=spinner; html=await renderAgentPanel(); break;
            case 'success':                html=renderSuccessPage(params.complaint); break;
            default:                       html=renderHomePage();
        }
        if (html) main.innerHTML=html;
    } catch(e) {
        console.error('Render:',e);
        main.innerHTML=`<div class="p-8 text-center"><p class="text-danger font-bold">حدث خطأ</p><p class="text-muted text-sm">${escapeHtml(e.message)}</p><button onclick="navigateTo('home')" class="mt-4 btn-primary px-6 py-2 rounded-lg">الرئيسية</button></div>`;
    }
}

function requireAdminPage() {
    if (!Store.data.currentUser) {
        const main=document.getElementById('main-content');
        if(main) main.innerHTML=`<div class="min-h-screen bg-pattern flex items-center justify-center"><div class="bg-white rounded-2xl shadow-sm p-10 text-center max-w-sm mx-4"><div class="text-5xl mb-4">🔒</div><h2 class="text-xl font-bold mb-2">يجب تسجيل الدخول</h2><a href="dashboard.php" class="btn-primary px-8 py-3 rounded-xl font-semibold inline-block mt-4">الذهاب لصفحة الدخول</a></div></div>`;
        document.getElementById('public-nav')?.classList.remove('hidden');
        return false;
    }
    return true;
}

// ==========================================
// HOME PAGE
// ==========================================
function renderHomePage() {
    return `
    <div class="bg-pattern min-h-screen">
        <section class="relative overflow-hidden py-20 sm:py-28">
            <div class="relative max-w-7xl mx-auto px-4 sm:px-6 text-center">
                <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center mx-auto mb-6">
                    <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                </div>
                <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-secondary mb-4">نظام إدارة الشكاوى والطلبات</h1>
                <p class="text-lg text-muted mb-8">حدائق القبة — قدّم شكواك أو طلبك وتابع حالته بسهولة</p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <button onclick="navigateTo('submit')" class="btn-primary px-8 py-4 rounded-xl text-lg font-semibold shadow-lg">قدم شكوى أو طلب</button>
                    <button onclick="navigateTo('track')" class="bg-white border-2 border-slate-200 text-secondary px-8 py-4 rounded-xl text-lg font-semibold hover:border-primary transition-colors">تتبع شكوى / طلب</button>
                </div>
            </div>
        </section>
        <section class="py-16 bg-white">
            <div class="max-w-7xl mx-auto px-4">
                <h2 class="text-2xl font-bold text-center text-secondary mb-10">أنواع الشكاوى والطلبات</h2>
                <div class="grid grid-cols-3 sm:grid-cols-5 gap-4">
                    ${Object.entries(CATEGORY_CONFIG).map(([name,cfg])=>`
                    <div class="bg-slate-50 rounded-xl p-5 text-center card-hover cursor-pointer border-2 border-transparent hover:border-primary transition-all" onclick="navigateTo('submit')">
                        <div class="text-3xl mb-2">${cfg.icon}</div>
                        <span class="text-sm font-medium text-secondary">${name}</span>
                    </div>`).join('')}
                </div>
            </div>
        </section>
        <footer class="bg-secondary text-white py-10 text-center">
            <p class="font-bold mb-1">نظام إدارة شكاوى وطلبات حدائق القبة</p>
            <p class="text-slate-400 text-sm">جميع الحقوق محفوظة © ${new Date().getFullYear()}</p>
        </footer>
    </div>`;
}

// ==========================================
// SUBMIT FORM
// ==========================================
let formData={}; let currentStep=1; const totalSteps=5;

function initSubmitForm() {
    formData={submission_type:'شكوى',category:'',title:'',description:'',address:'',district:'',name:'',phone:'',national_id:'',email:'',isAnonymous:false};
    currentStep=1; updateFormContainer();
}

function renderProgressBar(step) {
    const steps=['النوع','التفاصيل','الموقع','المرفقات','بياناتك'];
    return `<div class="mb-8 flex items-center">
        ${steps.map((s,i)=>`${i>0?`<div class="flex-1 h-1 mx-1 rounded-full ${i<step?'bg-success':'bg-slate-200'}"></div>`:''}
        <div class="flex flex-col items-center">
            <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold mb-1 ${i+1<step?'bg-success text-white':i+1===step?'bg-primary text-white':'bg-slate-200 text-muted'}">${i+1<step?'✓':i+1}</div>
            <span class="text-xs hidden sm:block ${i+1===step?'text-primary font-medium':'text-muted'}">${s}</span>
        </div>`).join('')}
    </div>`;
}

function renderSubmitPage() {
    return `<div class="min-h-screen bg-pattern py-8"><div class="max-w-3xl mx-auto px-4">
        <div class="mb-6 flex items-center gap-3">
            <button onclick="navigateTo('home')" class="text-muted hover:text-secondary p-1"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg></button>
            <h2 class="text-2xl font-bold">تقديم شكوى أو طلب</h2>
        </div>
        <div id="form-container" class="bg-white rounded-2xl shadow-sm p-8"></div>
    </div></div>`;
}

function renderStep(s) {
    const bar=renderProgressBar(s);
    if(s===1) return bar+renderTypeAndCategoryStep();
    if(s===2) return bar+renderDetailsStep();
    if(s===3) return bar+renderLocationStep();
    if(s===4) return bar+renderAttachmentsStep();
    return bar+renderUserInfoStep();
}

// الخطوة 1: نوع التقديم + الفئة في نفس الصفحة
function renderTypeAndCategoryStep() {
    return `
    <h3 class="text-lg font-semibold mb-4">نوع التقديم</h3>
    <div class="grid grid-cols-2 gap-4 mb-6">
        <div class="border-2 rounded-xl p-4 text-center cursor-pointer transition-all ${formData.submission_type==='شكوى'?'border-primary bg-primary/5':'border-slate-200 hover:border-primary/50'}"
             onclick="setType('شكوى',this)">
            <div class="text-3xl mb-2">📢</div>
            <div class="font-bold">شكوى</div>
            <div class="text-xs text-muted mt-1">للإبلاغ عن مشكلة</div>
        </div>
        <div class="border-2 rounded-xl p-4 text-center cursor-pointer transition-all ${formData.submission_type==='طلب'?'border-orange-400 bg-orange-50':'border-slate-200 hover:border-orange-300'}"
             onclick="setType('طلب',this)">
            <div class="text-3xl mb-2">📋</div>
            <div class="font-bold">طلب</div>
            <div class="text-xs text-muted mt-1">لطلب خدمة أو معاملة</div>
        </div>
    </div>
    <h3 class="text-lg font-semibold mb-4">الفئة</h3>
    <div class="grid grid-cols-3 sm:grid-cols-5 gap-3 mb-8">
        ${Object.entries(CATEGORY_CONFIG).map(([name,cfg])=>`
        <div class="category-card border-2 rounded-xl p-3 text-center cursor-pointer transition-all ${formData.category===name?'border-primary bg-primary/5':'border-slate-200 hover:border-primary/50'}"
             onclick="selectCategory('${name}',this)">
            <div class="text-xl mb-1">${cfg.icon}</div>
            <div class="text-xs font-medium">${name}</div>
        </div>`).join('')}
    </div>
    <div class="flex justify-end">
        <button onclick="nextStep()" class="btn-primary px-8 py-3 rounded-xl font-medium ${!formData.category?'opacity-50 cursor-not-allowed':''}">التالي ←</button>
    </div>`;
}

function setType(type, el) {
    formData.submission_type = type;
    document.querySelectorAll('.grid .border-2').forEach(c=>{ c.classList.remove('border-primary','bg-primary/5','border-orange-400','bg-orange-50'); c.classList.add('border-slate-200'); });
    if(type==='شكوى') { el.classList.add('border-primary','bg-primary/5'); }
    else               { el.classList.add('border-orange-400','bg-orange-50'); }
}

function renderDetailsStep() {
    return `<h3 class="text-lg font-semibold mb-2">تفاصيل ${formData.submission_type}</h3>
    <div class="flex items-center gap-2 mb-4">
        <span class="text-xs px-2 py-1 rounded-full font-medium ${formData.submission_type==='طلب'?'bg-orange-100 text-orange-700':'bg-primary/10 text-primary'}">${formData.submission_type==='طلب'?'📋 طلب':'📢 شكوى'}</span>
        <span class="text-xs text-muted">${CATEGORY_CONFIG[formData.category]?.icon||''} ${formData.category}</span>
    </div>
    <div class="space-y-4 mb-8">
        <div><label class="block text-sm font-medium mb-1">العنوان <span class="text-danger">*</span></label>
            <input type="text" id="title" value="${escapeHtml(formData.title)}" class="w-full px-4 py-3 border-2 rounded-xl input-focus" placeholder="اكتب عنواناً مختصراً..." maxlength="200"></div>
        <div><label class="block text-sm font-medium mb-1">الوصف التفصيلي <span class="text-danger">*</span></label>
            <textarea id="description" rows="5" class="w-full px-4 py-3 border-2 rounded-xl input-focus resize-none" placeholder="اشرح بالتفصيل..." maxlength="3000">${escapeHtml(formData.description)}</textarea></div>
    </div>
    <div class="flex justify-between">
        <button onclick="prevStep()" class="px-6 py-3 rounded-xl border-2 border-slate-200 hover:bg-slate-50">→ السابق</button>
        <button onclick="nextStep()" class="btn-primary px-8 py-3 rounded-xl font-medium">التالي ←</button>
    </div>`;
}

function renderLocationStep() {
    return `<h3 class="text-lg font-semibold mb-6">الموقع</h3>
    <div class="space-y-4 mb-8">
        <div><label class="block text-sm font-medium mb-1">المنطقة <span class="text-danger">*</span></label>
            <select id="district" class="w-full px-4 py-3 border-2 rounded-xl input-focus">
                <option value="">-- اختر المنطقة --</option>
                ${DISTRICTS.map(d=>`<option value="${d}" ${formData.district===d?'selected':''}>${d}</option>`).join('')}
            </select></div>
        <div><label class="block text-sm font-medium mb-1">العنوان التفصيلي (اختياري)</label>
            <textarea id="address" rows="2" class="w-full px-4 py-3 border-2 rounded-xl input-focus resize-none" placeholder="مثال: شارع الجمهورية، أمام...">${escapeHtml(formData.address)}</textarea></div>
    </div>
    <div class="flex justify-between">
        <button onclick="prevStep()" class="px-6 py-3 rounded-xl border-2 border-slate-200 hover:bg-slate-50">→ السابق</button>
        <button onclick="nextStep()" class="btn-primary px-8 py-3 rounded-xl font-medium">التالي ←</button>
    </div>`;
}

function renderAttachmentsStep() {
    return `<h3 class="text-lg font-semibold mb-6">المرفقات (اختياري)</h3>
    <div class="file-upload-zone rounded-xl p-10 text-center mb-4 cursor-pointer" onclick="document.getElementById('attach-file').click()">
        <div class="text-4xl mb-3">📎</div>
        <p class="text-muted text-sm">اضغط لرفع صورة أو PDF</p>
        <p class="text-xs text-muted mt-1">الحجم الأقصى: 5MB</p>
        <input type="file" id="attach-file" class="hidden" accept="image/*,.pdf" onchange="showAttachName(this)">
    </div>
    <p id="attach-name" class="text-sm text-success text-center"></p>
    <div class="flex justify-between mt-6">
        <button onclick="prevStep()" class="px-6 py-3 rounded-xl border-2 border-slate-200 hover:bg-slate-50">→ السابق</button>
        <button onclick="nextStep()" class="btn-primary px-8 py-3 rounded-xl font-medium">التالي ←</button>
    </div>`;
}
function showAttachName(i) { const p=document.getElementById('attach-name'); if(p&&i.files[0]) p.textContent='✓ '+i.files[0].name; }

function renderUserInfoStep() {
    const isRequest = formData.submission_type==='طلب';
    return `<h3 class="text-lg font-semibold mb-6">بياناتك الشخصية</h3>
    <div class="space-y-4 mb-6">
        <div><label class="block text-sm font-medium mb-1">الاسم الكامل <span class="text-danger">*</span></label>
            <input type="text" id="user-name" value="${escapeHtml(formData.name)}" class="w-full px-4 py-3 border-2 rounded-xl input-focus" placeholder="محمد أحمد علي"></div>
        <div><label class="block text-sm font-medium mb-1">رقم الهاتف <span class="text-danger">*</span></label>
            <input type="tel" id="user-phone" value="${escapeHtml(formData.phone)}" class="w-full px-4 py-3 border-2 rounded-xl input-focus" placeholder="01012345678" maxlength="11"></div>
        ${isRequest?`<div><label class="block text-sm font-medium mb-1">رقم البطاقة الوطنية <span class="text-danger">* (مطلوب في الطلبات)</span></label>
            <input type="text" id="national-id" value="${escapeHtml(formData.national_id)}" class="w-full px-4 py-3 border-2 rounded-xl input-focus font-mono" placeholder="14 رقماً" maxlength="14" pattern="\\d{14}">
            <p class="text-xs text-muted mt-1">أدخل 14 رقم بدون مسافات</p></div>`:''}
        <div><label class="block text-sm font-medium mb-1">البريد الإلكتروني (اختياري)</label>
            <input type="email" id="user-email" value="${escapeHtml(formData.email)}" class="w-full px-4 py-3 border-2 rounded-xl input-focus" placeholder="example@mail.com"></div>
    </div>
    <div class="flex justify-between">
        <button onclick="prevStep()" class="px-6 py-3 rounded-xl border-2 border-slate-200 hover:bg-slate-50">→ السابق</button>
        <button onclick="submitComplaint()" id="submit-btn" class="btn-primary px-8 py-3 rounded-xl font-medium">تقديم ${formData.submission_type}</button>
    </div>`;
}

function selectCategory(c,el) {
    formData.category=c;
    document.querySelectorAll('.category-card').forEach(x=>{ x.classList.remove('border-primary','bg-primary/5'); x.classList.add('border-slate-200'); });
    el.classList.add('border-primary','bg-primary/5'); el.classList.remove('border-slate-200');
    const btn=document.querySelector('button[onclick="nextStep()"]');
    if(btn) btn.classList.remove('opacity-50','cursor-not-allowed');
}

function nextStep() {
    if(currentStep===1) {
        if(!formData.category) return showNotification('اختر الفئة أولاً','error');
    }
    if(currentStep===2) {
        formData.title=document.getElementById('title')?.value.trim();
        formData.description=document.getElementById('description')?.value.trim();
        if(!formData.title||formData.title.length<5) return showNotification('العنوان قصير جداً (5 أحرف)','error');
        if(!formData.description||formData.description.length<20) return showNotification('الوصف قصير جداً (20 حرف)','error');
    }
    if(currentStep===3) {
        formData.district=document.getElementById('district')?.value;
        formData.address=document.getElementById('address')?.value.trim();
        if(!formData.district) return showNotification('اختر المنطقة','error');
    }
    if(currentStep<totalSteps) { currentStep++; updateFormContainer(); }
}
function prevStep()          { if(currentStep>1){currentStep--;updateFormContainer();} }
function updateFormContainer(){ const c=document.getElementById('form-container'); if(c) c.innerHTML=renderStep(currentStep); }

async function submitComplaint() {
    formData.name        = document.getElementById('user-name')?.value.trim();
    formData.phone       = document.getElementById('user-phone')?.value.trim();
    formData.national_id = document.getElementById('national-id')?.value.trim()||'';
    formData.email       = document.getElementById('user-email')?.value.trim();

    if(!formData.name||formData.name.length<2) return showNotification('أدخل اسمك كاملاً','error');
    if(!formData.phone) return showNotification('أدخل رقم هاتفك','error');
    if(!/^01[0125][0-9]{8}$/.test(formData.phone)) return showNotification('رقم الهاتف غير صحيح','error');
    if(formData.submission_type==='طلب' && !/^\d{14}$/.test(formData.national_id)) return showNotification('رقم البطاقة مطلوب (14 رقم) في الطلبات','error');
    if(formData.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) return showNotification('البريد غير صحيح','error');

    const btn=document.getElementById('submit-btn');
    if(btn){btn.disabled=true;btn.textContent='جاري الإرسال...';}
    const result=await Store.addComplaint(formData);
    if(result.success) {
        navigateTo('success',{complaint:{id:result.complaint_id,code:result.complaint_code,category:formData.category,type:formData.submission_type}});
    } else {
        showNotification(result.message||'حدث خطأ','error');
        if(btn){btn.disabled=false;btn.textContent='تقديم '+formData.submission_type;}
    }
}

// ==========================================
// SUCCESS PAGE — مع زرار تحميل الرقم
// ==========================================
function renderSuccessPage(c) {
    const catCfg=CATEGORY_CONFIG[c?.category]||CATEGORY_CONFIG['أخرى'];
    const isReq=c?.type==='طلب';
    setTimeout(()=>{
        const canvas=document.getElementById('qrcode');
        if(canvas&&c?.code&&typeof QRCode!=='undefined') QRCode.toCanvas(canvas,c.code,{width:160},e=>{ if(e) canvas.style.display='none'; });
        else if(canvas) canvas.style.display='none';
    },200);
    return `
    <div class="min-h-screen bg-pattern py-12 flex items-center">
        <div class="max-w-lg mx-auto px-4 w-full">
            <div class="bg-white rounded-2xl shadow-sm p-10 text-center">
                <div class="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
                    <svg class="w-10 h-10 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                </div>
                <h2 class="text-2xl font-bold mb-2">تم تقديم ${isReq?'الطلب':'الشكوى'} بنجاح!</h2>
                <p class="text-muted mb-6">احتفظ بالرقم لمتابعة حالته</p>

                <div class="bg-slate-50 border-2 rounded-2xl p-6 mb-4" id="receipt-card">
                    <div class="flex items-center justify-center gap-2 mb-2">
                        <span class="text-xs px-3 py-1 rounded-full font-medium ${isReq?'bg-orange-100 text-orange-700':'bg-primary/10 text-primary'}">${isReq?'📋 طلب':'📢 شكوى'}</span>
                        <span class="text-xs text-muted">${catCfg.icon} ${escapeHtml(c?.category||'')}</span>
                    </div>
                    <p class="text-xs text-muted mb-1">رقم ${isReq?'الطلب':'الشكوى'}</p>
                    <p class="text-3xl font-bold text-primary font-mono">${escapeHtml(c?.code||'')}</p>
                </div>

                <!-- زرار تحميل الرقم -->
                <button onclick="downloadReceipt('${escapeHtml(c?.code||'')}','${escapeHtml(c?.category||'')}','${isReq?'طلب':'شكوى'}')"
                    class="w-full mb-3 py-2.5 rounded-xl border-2 border-slate-200 hover:bg-slate-50 text-sm font-medium flex items-center justify-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    تحميل الرقم كصورة
                </button>

                <canvas id="qrcode" class="mx-auto mb-4 rounded-lg"></canvas>
                <p class="text-xs text-muted mb-8">امسح QR لمتابعة حالة ${isReq?'الطلب':'الشكوى'}</p>
                <div class="flex flex-col sm:flex-row gap-3">
                    <button onclick="navigateTo('track-result',{id:'${escapeHtml(c?.code||'')}'})" class="flex-1 btn-primary py-3 rounded-xl font-medium">تابع الحالة</button>
                    <button onclick="navigateTo('home')" class="flex-1 py-3 rounded-xl border-2 border-slate-200 font-medium hover:bg-slate-50">الرئيسية</button>
                </div>
            </div>
        </div>
    </div>`;
}

function downloadReceipt(code, category, type) {
    const canvas = document.createElement('canvas');
    canvas.width = 600; canvas.height = 300;
    const ctx = canvas.getContext('2d');
    // خلفية
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0,0,600,300);
    // شريط علوي
    ctx.fillStyle = '#0d9488';
    ctx.fillRect(0,0,600,80);
    // العنوان
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('نظام إدارة شكاوى حدائق القبة', 300, 35);
    ctx.font = '14px Arial';
    ctx.fillText(`${type} - ${category}`, 300, 62);
    // الرقم
    ctx.fillStyle = '#0d9488';
    ctx.font = 'bold 42px Courier New';
    ctx.fillText(code, 300, 175);
    // تاريخ
    ctx.fillStyle = '#64748b';
    ctx.font = '13px Arial';
    ctx.fillText('تاريخ التقديم: ' + new Date().toLocaleDateString('ar-EG'), 300, 220);
    ctx.fillText('احتفظ بهذا الرقم لمتابعة حالة '+type, 300, 255);
    // حد سفلي
    ctx.fillStyle = '#0d9488';
    ctx.fillRect(0,280,600,20);
    // تحميل
    const link = document.createElement('a');
    link.download = `receipt-${code}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
}

// ==========================================
// TRACK PAGE — برقم الكود فقط
// ==========================================
function renderTrackPage() {
    return `<div class="min-h-screen bg-pattern py-12"><div class="max-w-lg mx-auto px-4">
        <div class="bg-white rounded-2xl shadow-sm p-8">
            <div class="text-center mb-8">
                <div class="text-4xl mb-3">🔍</div>
                <h2 class="text-xl font-bold mb-1">تتبع الشكوى أو الطلب</h2>
                <p class="text-muted text-sm">أدخل رقم الشكوى أو الطلب فقط<br><span class="text-xs">(مثال: C-ELC-123456 أو R-HLT-789012)</span></p>
            </div>
            <input type="text" id="track-input" class="w-full px-4 py-4 border-2 rounded-xl text-lg mb-4 input-focus text-center font-mono"
                placeholder="C-ELC-123456" onkeydown="if(event.key==='Enter') trackComplaint()">
            <button onclick="trackComplaint()" class="w-full btn-primary py-4 rounded-xl font-semibold text-lg">بحث</button>
        </div>
    </div></div>`;
}

async function trackComplaint() {
    const input=document.getElementById('track-input')?.value.trim();
    if(!input) return showNotification('أدخل رقم الشكوى أو الطلب','error');
    Store.invalidateCache('track_'+input);
    const res=await Store.getTrackData(input);
    if(res.success) navigateTo('track-result',{id:input});
    else showNotification(res.message||'لم يتم العثور على نتائج','error');
}

async function renderTrackResultPage(query) {
    const res=await Store.getTrackData(query);
    if(!res.success) return `<div class="p-8 text-center text-muted"><p class="text-5xl mb-4">😕</p><p class="mb-4">${escapeHtml(res.message||'لا توجد نتائج')}</p><button onclick="navigateTo('track')" class="btn-primary px-6 py-2 rounded-lg">بحث جديد</button></div>`;

    const c=res.complaint; const history=res.history||[]; const comments=res.comments||[];
    const catCfg=CATEGORY_CONFIG[c.category]||CATEGORY_CONFIG['أخرى'];
    const isReq=c.submission_type==='طلب';

    return `
    <div class="min-h-screen bg-pattern py-12">
        <div class="max-w-3xl mx-auto px-4">
            <button onclick="navigateTo('track')" class="flex items-center gap-2 text-muted hover:text-secondary mb-6">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>بحث جديد
            </button>
            <div class="bg-white rounded-2xl shadow-sm p-6 mb-6" style="border-top:4px solid ${STATUS_CONFIG[c.status]?.color||'#0d9488'}">
                <div class="flex flex-wrap justify-between items-start gap-3 mb-4">
                    <div>
                        <div class="flex items-center gap-2 mb-1">
                            <span class="text-xs px-2 py-0.5 rounded-full font-medium ${isReq?'bg-orange-100 text-orange-700':'bg-primary/10 text-primary'}">${isReq?'📋 طلب':'📢 شكوى'}</span>
                            <span class="font-mono text-sm font-bold text-primary">${escapeHtml(c.complaint_code)}</span>
                            <span class="text-xs text-muted">${catCfg.icon} ${c.category}</span>
                        </div>
                        <h2 class="text-xl font-bold">${escapeHtml(c.title)}</h2>
                        <p class="text-xs text-muted mt-1">${c.district||''} · ${formatDate(c.created_at)}</p>
                    </div>
                    ${statusBadge(c.status)}
                </div>
                <p class="text-slate-600 bg-slate-50 rounded-xl p-4 leading-relaxed">${escapeHtml(c.description)}</p>
                <!-- زر طباعة الشكوى -->
                <button onclick="printComplaint()" class="mt-4 flex items-center gap-2 text-sm text-muted hover:text-secondary border border-slate-200 px-4 py-2 rounded-lg hover:bg-slate-50 transition-colors">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                    طباعة
                </button>
            </div>
            <!-- مراحل -->
            <div class="bg-white rounded-2xl shadow-sm p-6 mb-6">
                <h3 class="font-bold mb-6">مراحل ${isReq?'الطلب':'الشكوى'}</h3>
                <div class="space-y-4">
                    ${history.length===0?'<p class="text-muted text-sm">لا يوجد سجل</p>':
                    history.map((x,i)=>{ const cfg=STATUS_CONFIG[x.status]||STATUS_CONFIG['تم الاستلام'];
                        return `<div class="timeline-item ${i>0?'opacity-70':''}">
                            <div class="timeline-dot" style="background:${cfg.color}"></div>
                            <div class="flex justify-between items-center">
                                <span class="font-medium text-sm" style="color:${cfg.color}">${x.status}</span>
                                <span class="text-xs text-muted">${formatDate(x.timestamp)}</span>
                            </div>
                        </div>`; }).join('')}
                </div>
            </div>
            <!-- ردود -->
            <div class="bg-white rounded-2xl shadow-sm p-6 mb-6">
                <h3 class="font-bold mb-4">الردود والتواصل</h3>
                <div class="space-y-3 mb-4 max-h-96 overflow-y-auto" id="chat-box">
                    ${comments.length===0?'<p class="text-center text-muted py-8 text-sm">لا توجد ردود حتى الآن</p>':
                    comments.map(x=>`
                    <div class="flex ${x.user_type==='customer'?'justify-end':'justify-start'}">
                        <div class="max-w-xs lg:max-w-md">
                            <div class="text-xs text-muted mb-1 ${x.user_type==='customer'?'text-left':'text-right'}">
                                ${x.user_type==='admin'||x.user_type==='agent'?`🏛️ ${escapeHtml(x.user_name||'الإدارة')}`:'🙋 أنت'} · ${formatTime(x.created_at)}
                            </div>
                            <div class="px-4 py-3 rounded-2xl ${x.user_type==='customer'?'bg-primary text-white rounded-tl-sm':'bg-slate-100 text-slate-800 rounded-tr-sm'}">
                                <p class="text-sm leading-relaxed">${escapeHtml(x.message)}</p>
                                ${(x.file_path&&typeof x.file_path==='string')?renderAttachment(x.file_path):''}
                            </div>
                        </div>
                    </div>`).join('')}
                </div>
                <!-- رد العميل -->
                <div class="border-t pt-4">
                    <textarea id="customer-reply" class="w-full px-4 py-3 border-2 rounded-xl resize-none mb-3 input-focus text-sm" rows="2" placeholder="اكتب ردك هنا..."></textarea>
                    <div class="flex items-center gap-2 mb-3">
                        <label class="cursor-pointer bg-slate-100 hover:bg-slate-200 transition-colors p-2.5 rounded-lg">
                            <svg class="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
                            <input type="file" id="reply-file" class="hidden" accept="image/*,.pdf">
                        </label>
                        <span id="file-name" class="text-xs text-muted">لم يتم اختيار ملف</span>
                    </div>
                    <button onclick="submitCustomerReply(${c.id},'${escapeHtml(query)}')" class="w-full btn-primary py-3 rounded-xl text-sm font-medium">إرسال الرد</button>
                </div>
            </div>
        </div>
    </div>`;
}

function printComplaint() { window.print(); }

async function submitCustomerReply(id,query) {
    const msg=document.getElementById('customer-reply')?.value.trim();
    const fi=document.getElementById('reply-file');
    if(!msg&&(!fi||fi.files.length===0)) return showNotification('اكتب رداً أو أرفق ملفاً','error');
    const fd=new FormData();
    fd.append('complaint_id',id); fd.append('message',msg||'');
    if(fi?.files.length>0) fd.append('file',fi.files[0]);
    try {
        const res=await fetch('api/admin.php?action=add_customer_reply',{method:'POST',body:fd,credentials:'include'});
        const result=JSON.parse((await res.text()).trim());
        if(result.success) { showNotification('تم إرسال ردك','success'); Store.invalidateCache('track_'+query); navigateTo('track-result',{id:query}); }
        else showNotification(result.message||'خطأ','error');
    } catch(e) { showNotification('خطأ في الاتصال','error'); }
}

// ==========================================
// ATTACHMENT RENDERER
// ==========================================
function renderAttachment(filePath) {
    if(!filePath||typeof filePath!=='string') return '';
    const ext=filePath.split('.').pop().toLowerCase();
    const name=filePath.split('/').pop();
    const isImg=['jpg','jpeg','png','gif','webp'].includes(ext);
    const isPDF=ext==='pdf';

    if(isImg) return `
        <div class="mt-2 rounded-xl overflow-hidden border border-slate-200 bg-white" style="max-width:260px">
            <div class="relative group cursor-pointer" onclick="openLightbox('${filePath}','${escapeHtml(name)}')">
                <img src="${filePath}" class="w-full object-cover" style="max-height:140px;object-fit:cover" onerror="this.parentElement.parentElement.innerHTML='<div class=\\'p-2 text-xs text-muted\\'>⚠️ تعذر التحميل</div>'">
                <div class="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100"><span class="text-white text-xs bg-black/50 px-2 py-1 rounded-full">🔍 معاينة</span></div>
            </div>
            <div class="flex justify-between items-center px-2 py-1.5 bg-slate-50">
                <span class="text-xs text-muted truncate max-w-28">${escapeHtml(name)}</span>
                <div class="flex gap-1 flex-shrink-0">
                    <button onclick="printFile('${filePath}')" class="text-xs text-slate-500 hover:text-secondary px-1" title="طباعة">🖨️</button>
                    <a href="${filePath}" download="${escapeHtml(name)}" class="text-xs text-primary hover:underline" onclick="event.stopPropagation()">⬇</a>
                </div>
            </div>
        </div>`;

    if(isPDF) return `
        <div class="mt-2 flex items-center gap-2 bg-red-50 border border-red-100 rounded-xl px-3 py-2" style="max-width:260px">
            <span class="text-red-500 text-xl flex-shrink-0">📄</span>
            <span class="text-xs text-slate-700 truncate flex-1">${escapeHtml(name)}</span>
            <button onclick="printFile('${filePath}')" class="text-xs text-slate-500 hover:text-secondary flex-shrink-0" title="طباعة">🖨️</button>
            <a href="${filePath}" target="_blank" class="text-xs text-slate-500 hover:text-slate-700 flex-shrink-0">فتح</a>
            <a href="${filePath}" download="${escapeHtml(name)}" class="text-xs text-primary hover:underline flex-shrink-0">⬇</a>
        </div>`;

    return `
        <div class="mt-2 flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2" style="max-width:260px">
            <span class="text-xl flex-shrink-0">📎</span>
            <span class="text-xs truncate flex-1">${escapeHtml(name)}</span>
            <a href="${filePath}" download="${escapeHtml(name)}" class="text-xs text-primary hover:underline flex-shrink-0">⬇</a>
        </div>`;
}

function printFile(url) {
    const w=window.open(url,'_blank');
    if(w) w.onload=()=>{ w.print(); };
}

function openLightbox(src,fileName) {
    document.getElementById('lightbox-overlay')?.remove();
    const o=document.createElement('div');
    o.id='lightbox-overlay';
    o.style.cssText='position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,0.92);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:16px';
    o.onclick=e=>{ if(e.target===o) o.remove(); };
    o.innerHTML=`
        <div style="position:absolute;top:12px;left:0;right:0;display:flex;justify-content:space-between;align-items:center;padding:0 16px">
            <span style="color:#e2e8f0;font-size:12px;max-width:60%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(fileName)}</span>
            <div style="display:flex;gap:8px">
                <button onclick="printFile('${src}')" style="background:#374151;color:#fff;border:none;padding:5px 12px;border-radius:8px;font-size:12px;cursor:pointer">🖨️ طباعة</button>
                <a href="${src}" download="${escapeHtml(fileName)}" style="background:#0d9488;color:#fff;padding:5px 12px;border-radius:8px;font-size:12px;text-decoration:none" onclick="event.stopPropagation()">⬇ تنزيل</a>
                <button onclick="document.getElementById('lightbox-overlay').remove()" style="background:#374151;color:#fff;border:none;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
            </div>
        </div>
        <img src="${src}" style="max-width:90vw;max-height:80vh;object-fit:contain;border-radius:12px" onerror="this.outerHTML='<p style=color:#ef4444>⚠️ تعذر التحميل</p>'">
        <p style="color:#64748b;font-size:11px;margin-top:10px">اضغط خارج الصورة للإغلاق · Escape</p>`;
    document.body.appendChild(o);
    const h=e=>{ if(e.key==='Escape'){o.remove();document.removeEventListener('keydown',h);} };
    document.addEventListener('keydown',h);
}

// ==========================================
// LOGIN PAGE
// ==========================================
function renderLoginPage() {
    return `<div class="min-h-screen bg-pattern py-12 flex items-center"><div class="max-w-md mx-auto px-4 w-full"><div class="bg-white rounded-2xl shadow-sm p-8 text-center"><p class="text-muted mb-4">لوحة التحكم متاحة من رابط خاص</p><a href="dashboard.php" class="btn-primary px-8 py-3 rounded-xl font-semibold inline-block">الذهاب للوحة التحكم</a><div class="mt-4"><button onclick="navigateTo('home')" class="text-muted text-sm hover:text-secondary">العودة للرئيسية</button></div></div></div></div>`;
}

// ==========================================
// ADMIN SIDEBAR
// ==========================================
function renderAdminSidebar(active) {
    const user=Store.data.currentUser;
    if(!user) return '';
    
    const isSuperAdmin = user.role === 'super_admin';
    const isAdmin = user.role === 'admin' || user.role === 'super_admin';
    const isSupervisor = user.role === 'supervisor';
    
    const links=[
        {page:'admin',key:'dashboard',label:'لوحة التحكم',icon:'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6',show:true},
        {page:'admin-complaints',key:'complaints',label:'الشكاوى والطلبات',icon:'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2',show:true},
        {page:'admin-requests',key:'requests',label:'طلبات التغيير',icon:'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',show:isAdmin||isSupervisor},
        {page:'admin-users',key:'users',label:'المستخدمين',icon:'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z',show:isSuperAdmin},
        {page:'admin-reports',key:'reports',label:'التقارير',icon:'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',show:isAdmin||isSupervisor},
    ];
    
    const roleLabel = {
        'super_admin': 'مدير عام',
        'admin': 'مدير',
        'supervisor': 'مشرف',
        'agent': 'موظف'
    }[user.role] || 'موظف';
    
    return `
    <aside class="sidebar fixed lg:static inset-y-0 right-0 w-64 bg-secondary text-white z-40 flex flex-col">
        <div class="p-5 border-b border-slate-700">
            <div class="font-bold text-lg">🏛️ لوحة الإدارة</div>
            ${user?`<div class="text-xs text-slate-400 mt-1">${escapeHtml(user.name)} · ${roleLabel}</div>`:''}
        </div>
        <nav class="flex-1 p-4 space-y-1 overflow-y-auto">
            ${links.filter(l=>l.show).map(l=>`<a href="#" onclick="navigateTo('${l.page}');return false;" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${active===l.key?'bg-primary text-white':'hover:bg-slate-700 text-slate-300'}">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="${l.icon}"/></svg>
                ${l.label}
            </a>`).join('')}
        </nav>
        <div class="p-4 border-t border-slate-700">
            <a href="/" class="block text-center text-xs text-slate-500 hover:text-slate-300 mb-2">← الموقع الرئيسي</a>
            <button onclick="logout()" class="w-full py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-sm font-medium">تسجيل الخروج</button>
        </div>
    </aside>`;
}

// ==========================================
// ADMIN DASHBOARD
// ==========================================
async function renderAdminDashboard() {
    if(!requireAdminPage()) return '';
    const [stats,complaints,notifs]=await Promise.all([Store.getStats(),Store.getComplaints('&limit=5'),Store.getNotifications()]);
    const recent=complaints.slice(0,5);
    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('dashboard')}
        <main class="flex-1 p-6 overflow-auto">
            <h1 class="text-2xl font-bold mb-6">لوحة التحكم</h1>
            <!-- إشعارات الردود غير المقروءة -->
            ${notifs.length>0?`
            <div class="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-6">
                <div class="flex items-center gap-2 mb-3">
                    <span class="text-amber-600 font-bold">🔔 ردود جديدة من المواطنين (${notifs.length})</span>
                </div>
                <div class="space-y-2">
                    ${notifs.slice(0,3).map(n=>`
                    <div class="flex justify-between items-center bg-white rounded-xl px-4 py-2">
                        <span class="font-mono text-xs text-primary">${escapeHtml(n.complaint_code)}</span>
                        <span class="text-sm truncate flex-1 mx-3">${escapeHtml(n.title)}</span>
                        <button onclick="navigateTo('admin-complaint-detail',{id:${n.id}})" class="text-xs text-primary hover:underline flex-shrink-0">عرض</button>
                    </div>`).join('')}
                    ${notifs.length>3?`<button onclick="navigateTo('admin-complaints',{unread:true})" class="text-xs text-amber-600 hover:underline">+ عرض ${notifs.length-3} أخرى</button>`:''}
                </div>
            </div>`:''}
            <!-- إحصائيات -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                ${[
                    {val:stats.total,      label:'الإجمالي',   color:'#0d9488',bg:'#f0fdfa'},
                    {val:stats.complaints, label:'شكاوى',      color:'#3b82f6',bg:'#eff6ff'},
                    {val:stats.requests,   label:'طلبات',      color:'#f97316',bg:'#fff7ed'},
                    {val:stats.open,       label:'مفتوحة',     color:'#f59e0b',bg:'#fffbeb'},
                    {val:stats.closed,     label:'محلولة',     color:'#10b981',bg:'#f0fdf4'},
                    {val:stats.unread||0,  label:'ردود جديدة', color:'#ef4444',bg:'#fef2f2'},
                ].map(s=>`<div class="rounded-2xl p-5 shadow-sm" style="background:${s.bg}">
                    <div class="text-3xl font-bold mb-1" style="color:${s.color}">${s.val}</div>
                    <div class="text-muted text-sm">${s.label}</div>
                </div>`).join('')}
            </div>
            <!-- أحدث الشكاوى -->
            <div class="bg-white rounded-2xl shadow-sm p-6">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="font-bold text-lg">أحدث الشكاوى والطلبات</h2>
                    <button onclick="navigateTo('admin-complaints')" class="text-primary text-sm hover:underline">عرض الكل</button>
                </div>
                ${recent.length===0?'<p class="text-center text-muted py-8">لا توجد شكاوى</p>':
                `<div class="overflow-x-auto"><table class="w-full text-right text-sm">
                    <thead class="bg-slate-50 border-b"><tr><th class="p-3">الكود</th><th class="p-3">النوع</th><th class="p-3">العنوان</th><th class="p-3">الحالة</th><th class="p-3"></th></tr></thead>
                    <tbody>${recent.map(c=>`<tr class="border-b hover:bg-slate-50" style="border-right:3px solid ${STATUS_CONFIG[c.status]?.color||'#e2e8f0'}">
                        <td class="p-3 font-mono text-xs text-primary">${escapeHtml(c.complaint_code||c.id)}</td>
                        <td class="p-3"><span class="text-xs px-2 py-0.5 rounded-full ${c.submission_type==='طلب'?'bg-orange-100 text-orange-700':'bg-primary/10 text-primary'}">${c.submission_type||'شكوى'}</span></td>
                        <td class="p-3 font-medium max-w-xs"><div class="truncate">${escapeHtml(c.title)}</div></td>
                        <td class="p-3">${statusBadge(c.status)}</td>
                        <td class="p-3"><button onclick="navigateTo('admin-complaint-detail',{id:${c.id}})" class="text-primary hover:underline text-xs">عرض</button></td>
                    </tr>`).join('')}</tbody>
                </table></div>`}
            </div>
        </main>
    </div>`;
}

// ==========================================
// ADMIN COMPLAINTS
// ==========================================
async function renderAdminComplaints(params={}) {
    if(!requireAdminPage()) return '';
    let qs='';
    if(params.status)   qs+=`&status=${encodeURIComponent(params.status)}`;
    if(params.category) qs+=`&category=${encodeURIComponent(params.category)}`;
    if(params.type)     qs+=`&submission_type=${encodeURIComponent(params.type)}`;
    if(params.district) qs+=`&district=${encodeURIComponent(params.district)}`;
    const complaints=await Store.getComplaints(qs);

    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('complaints')}
        <main class="flex-1 p-6 overflow-auto">
            <div class="flex flex-wrap justify-between items-center gap-4 mb-4">
                <h1 class="text-2xl font-bold">الشكاوى والطلبات (${complaints.length})</h1>
                <div class="flex gap-2">
                    <button onclick="exportPhoneNumbers()" class="flex items-center gap-2 border-2 border-primary text-primary px-4 py-2 rounded-xl text-sm hover:bg-primary hover:text-white transition-colors">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                        تصدير الأرقام والأسماء
                    </button>
                    <button onclick="printComplaints()" class="flex items-center gap-2 border-2 border-slate-200 px-4 py-2 rounded-xl text-sm hover:bg-slate-50">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                        طباعة القائمة
                    </button>
                </div>
            </div>
            <!-- فلاتر -->
            <div class="bg-white rounded-xl p-4 mb-4 flex flex-wrap gap-2">
                <input type="text" id="search-input" placeholder="بحث بالكود أو الهاتف أو الاسم..." onkeyup="liveFilter()"
                    class="px-3 py-2 border-2 rounded-xl text-sm input-focus flex-1 min-w-36">
                <!-- نوع التقديم -->
                <div class="flex gap-1">
                    <button onclick="applyFilter({type:''})" class="px-3 py-1.5 rounded-lg text-xs border-2 ${!params.type?'border-primary text-primary':'border-slate-200 text-muted'} hover:border-primary transition-colors">الكل</button>
                    <button onclick="applyFilter({type:'شكوى'})" class="px-3 py-1.5 rounded-lg text-xs border-2 ${params.type==='شكوى'?'border-primary bg-primary/5 text-primary':'border-slate-200 text-muted'}">📢 شكاوى</button>
                    <button onclick="applyFilter({type:'طلب'})" class="px-3 py-1.5 rounded-lg text-xs border-2 ${params.type==='طلب'?'border-orange-400 bg-orange-50 text-orange-700':'border-slate-200 text-muted'}">📋 طلبات</button>
                </div>
                <select id="filter-status" onchange="applyFilter({status:this.value,type:'${params.type||''}'})" class="px-3 py-2 border-2 rounded-xl text-sm input-focus">
                    <option value="">كل الحالات</option>
                    ${Object.keys(STATUS_CONFIG).map(s=>`<option value="${s}" ${params.status===s?'selected':''}>${s}</option>`).join('')}
                </select>
                <select id="filter-cat" onchange="applyFilter({category:this.value,type:'${params.type||''}',status:'${params.status||''}'})" class="px-3 py-2 border-2 rounded-xl text-sm input-focus">
                    <option value="">كل الفئات</option>
                    ${Object.keys(CATEGORY_CONFIG).map(c=>`<option value="${c}" ${params.category===c?'selected':''}>${c}</option>`).join('')}
                </select>
                <select id="filter-district" onchange="applyFilter({district:this.value,type:'${params.type||''}',status:'${params.status||''}',category:'${params.category||''}'})" class="px-3 py-2 border-2 rounded-xl text-sm input-focus">
                    <option value="">كل المناطق</option>
                    ${DISTRICTS.map(d=>`<option value="${d}" ${params.district===d?'selected':''}>${d}</option>`).join('')}
                </select>
            </div>
            <!-- جدول -->
            <div class="bg-white rounded-2xl shadow-sm overflow-hidden" id="complaints-print-area">
                <div class="overflow-x-auto">
                    <table class="w-full text-right text-sm" id="complaints-table">
                        <thead class="bg-slate-50 border-b"><tr>
                            <th class="p-3">الكود</th><th class="p-3">النوع</th><th class="p-3">العنوان</th>
                            <th class="p-3">الفئة</th><th class="p-3">المنطقة</th><th class="p-3">الحالة</th>
                            <th class="p-3">المُكلَّف</th><th class="p-3">ردود</th><th class="p-3">التاريخ</th><th class="p-3"></th>
                        </tr></thead>
                        <tbody id="complaints-body">${renderComplaintsRows(complaints)}</tbody>
                    </table>
                </div>
                ${complaints.length===0?'<p class="text-center text-muted py-12">لا توجد نتائج</p>':''}
            </div>
        </main>
    </div>`;
}

function renderComplaintsRows(complaints) {
    return complaints.map(c=>{
        const catCfg=CATEGORY_CONFIG[c.category]||CATEGORY_CONFIG['أخرى'];
        const isReq=c.submission_type==='طلب';
        const hasUnread=c.has_unread_reply==1;
        return `<tr class="border-b hover:bg-slate-50 complaint-row" data-text="${escapeHtml(c.title||'').toLowerCase()} ${escapeHtml(c.complaint_code||'').toLowerCase()} ${escapeHtml(c.phone||'').toLowerCase()} ${escapeHtml(c.name||'').toLowerCase()}"
            style="border-right:4px solid ${STATUS_CONFIG[c.status]?.color||'#e2e8f0'}">
            <td class="p-3 font-mono text-xs text-primary font-bold">${escapeHtml(c.complaint_code||c.id)}</td>
            <td class="p-3"><span class="text-xs px-2 py-0.5 rounded-full ${isReq?'bg-orange-100 text-orange-700':'bg-primary/10 text-primary'}">${c.submission_type||'شكوى'}</span></td>
            <td class="p-3 max-w-xs"><div class="truncate font-medium">${escapeHtml(c.title)}</div></td>
            <td class="p-3 text-xs">${catCfg.icon} ${c.category}</td>
            <td class="p-3 text-xs text-muted">${c.district||'—'}</td>
            <td class="p-3">${statusBadge(c.status)}</td>
            <td class="p-3 text-xs text-muted">${escapeHtml(c.assigned_name||'—')}</td>
            <td class="p-3">${hasUnread?'<span class="w-2 h-2 rounded-full bg-red-500 inline-block animate-pulse" title="رد جديد"></span>':''}</td>
            <td class="p-3 text-muted text-xs">${formatDate(c.created_at)}</td>
            <td class="p-3"><button onclick="navigateTo('admin-complaint-detail',{id:${c.id}})" class="text-primary hover:underline text-xs font-medium">عرض</button></td>
        </tr>`;
    }).join('');
}

function liveFilter() {
    const q=document.getElementById('search-input')?.value.toLowerCase()||'';
    document.querySelectorAll('.complaint-row').forEach(r=>{ r.style.display=r.dataset.text.includes(q)?'':'none'; });
}

function applyFilter(overrides={}) {
    const status   = overrides.status   !== undefined ? overrides.status   : (document.getElementById('filter-status')?.value||'');
    const category = overrides.category !== undefined ? overrides.category : (document.getElementById('filter-cat')?.value||'');
    const type     = overrides.type     !== undefined ? overrides.type     : '';
    const district = overrides.district !== undefined ? overrides.district : (document.getElementById('filter-district')?.value||'');
    navigateTo('admin-complaints',{status,category,type,district});
}

function printComplaints() {
    const area=document.getElementById('complaints-print-area');
    if(!area) return;
    const w=window.open('','_blank');
    w.document.write(`<html dir="rtl"><head><title>قائمة الشكاوى والطلبات</title><style>body{font-family:Arial,sans-serif;font-size:12px} table{width:100%;border-collapse:collapse} th,td{border:1px solid #ddd;padding:6px;text-align:right} th{background:#f1f5f9}</style></head><body><h2>قائمة الشكاوى والطلبات — ${new Date().toLocaleDateString('ar-EG')}</h2>${area.innerHTML}</body></html>`);
    w.document.close(); w.print();
}

async function exportPhoneNumbers() {
    const complaints=await Store.getComplaints();
    if(complaints.length===0) return showNotification('لا توجد بيانات','error');
    
    // إنشاء CSV
    let csv='الاسم,رقم التليفون,الكود,العنوان,التاريخ\n';
    complaints.forEach(c=>{
        const name=(c.name||'').replace(/,/g,' ');
        const phone=c.phone||'—';
        const code=c.complaint_code||c.id;
        const title=(c.title||'').replace(/,/g,' ');
        const date=formatDate(c.created_at);
        csv+=`"${name}","${phone}","${code}","${title}","${date}"\n`;
    });
    
    // تحميل الملف
    const blob=new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8;'});
    const link=document.createElement('a');
    link.href=URL.createObjectURL(blob);
    link.download=`ارقام_التليفونات_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    showNotification('تم تصدير '+complaints.length+' سجل','success');
}

// ==========================================
// ADMIN COMPLAINT DETAIL
// ==========================================
async function renderAdminComplaintDetail(id) {
    if(!requireAdminPage()) return '';
    // الأدمن يستخدم endpoint خاص به يجلب كل البيانات بالـ id مباشرة
    // بما فيها الملاحظات الداخلية
    const res=await Store.getComplaintDetail(id);

    if(!res.success) return `<div class="p-8 text-center text-muted">
        <p class="text-5xl mb-4">😕</p>
        <p class="font-bold text-danger mb-2">${res.message||'الشكوى غير موجودة'}</p>
        <p class="text-xs text-muted mb-4">ID المطلوب: ${id}</p>
        <button onclick="navigateTo('admin-complaints')" class="btn-primary px-6 py-2 rounded-lg">العودة للقائمة</button>
    </div>`;
    const c=res.complaint; const history=res.history||[]; const comments=res.comments||[];
    const catCfg=CATEGORY_CONFIG[c.category]||CATEGORY_CONFIG['أخرى'];
    const isReq=c.submission_type==='طلب';

    // جلب المستخدمين للتكليف
    const users=await Store.getUsers();

    // وضع علامة مقروء تلقائياً عند فتح الشكوى
    if(c.has_unread_reply) Store.markRead(c.id);

    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('complaints')}
        <main class="flex-1 p-6 overflow-auto">
            <div class="flex items-center gap-3 mb-6">
                <button onclick="navigateTo('admin-complaints')" class="flex items-center gap-2 text-muted hover:text-secondary">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>العودة
                </button>
                <button onclick="printComplaintDetail()" class="flex items-center gap-2 border-2 border-slate-200 px-4 py-2 rounded-xl text-sm hover:bg-slate-50 mr-auto">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                    طباعة
                </button>
            </div>
            <div class="grid lg:grid-cols-3 gap-6" id="complaint-detail-print">
                <div class="lg:col-span-2 space-y-6">
                    <!-- بطاقة الشكوى -->
                    <div class="bg-white rounded-2xl shadow-sm p-6" style="border-top:4px solid ${STATUS_CONFIG[c.status]?.color||'#0d9488'}">
                        <div class="flex flex-wrap justify-between items-start gap-3 mb-4">
                            <div>
                                <div class="flex items-center gap-2 mb-1">
                                    <span class="text-xs px-2 py-0.5 rounded-full font-medium ${isReq?'bg-orange-100 text-orange-700':'bg-primary/10 text-primary'}">${isReq?'📋 طلب':'📢 شكوى'}</span>
                                    <span class="font-mono text-sm font-bold text-primary">${escapeHtml(c.complaint_code||c.id)}</span>
                                    <span class="text-xs text-muted">${catCfg.icon} ${c.category}</span>
                                </div>
                                <h1 class="text-xl font-bold">${escapeHtml(c.title)}</h1>
                                <p class="text-sm text-muted mt-1">${c.district||''} · ${formatDate(c.created_at)}</p>
                            </div>
                            ${statusBadge(c.status)}
                        </div>
                        <p class="text-slate-600 bg-slate-50 rounded-xl p-4 leading-relaxed">${escapeHtml(c.description)}</p>
                        ${c.address?`<p class="text-sm text-muted mt-3">📍 ${escapeHtml(c.address)}</p>`:''}
                    </div>

                    <!-- الردود مع تمييز الداخلية -->
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <h3 class="font-bold mb-4">الردود والملاحظات (${comments.length})</h3>
                        <div class="space-y-3 mb-4 max-h-80 overflow-y-auto">
                            ${comments.length===0?'<p class="text-muted text-sm py-4 text-center">لا توجد ردود</p>':
                            comments.map(x=>`
                            <div class="flex gap-3 ${x.user_type==='customer'?'flex-row-reverse':''}">
                                <div class="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-sm ${x.user_type==='admin'?'bg-primary/10 text-primary':x.user_type==='agent'?'bg-blue-100 text-blue-600':'bg-slate-100 text-muted'}">
                                    ${x.user_type==='admin'?'🏛️':x.user_type==='agent'?'👤':'🙋'}
                                </div>
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-xs text-muted">${x.user_type==='customer'?'المواطن':escapeHtml(x.user_name||'الإدارة')} · ${formatDate(x.created_at)}</span>
                                        ${x.is_internal?'<span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">🔒 ملاحظة داخلية</span>':''}
                                    </div>
                                    <div class="rounded-xl p-3 text-sm ${x.is_internal?'bg-yellow-50 border border-yellow-200':'bg-slate-50'}">${escapeHtml(x.message)}</div>
                                    ${(x.file_path&&typeof x.file_path==='string')?renderAttachment(x.file_path):''}
                                </div>
                            </div>`).join('')}
                        </div>
                        <!-- نموذج الرد -->
                        <div class="border-t pt-4 space-y-3">
                            <textarea id="admin-comment" class="w-full px-4 py-3 border-2 rounded-xl resize-none input-focus text-sm" rows="2" placeholder="اكتب رداً للمواطن..."></textarea>
                            <!-- رفع ملف من الأدمن -->
                            <div class="flex items-center gap-2">
                                <label class="cursor-pointer bg-slate-100 hover:bg-slate-200 transition-colors p-2.5 rounded-lg" title="إرفاق ملف">
                                    <svg class="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
                                    <input type="file" id="admin-file" class="hidden" accept="image/*,.pdf" onchange="document.getElementById('admin-file-name').textContent=this.files[0]?.name||''">
                                </label>
                                <span id="admin-file-name" class="text-xs text-muted"></span>
                            </div>
                            <div class="flex gap-2">
                                <button onclick="submitAdminComment(${c.id},false)" class="flex-1 btn-primary px-4 py-2.5 rounded-xl text-sm font-medium">إرسال للمواطن</button>
                                <button onclick="submitAdminComment(${c.id},true)" class="px-4 py-2.5 rounded-xl text-sm border-2 border-yellow-300 text-yellow-700 hover:bg-yellow-50" title="ملاحظة داخلية لا يراها المواطن">
                                    🔒 ملاحظة داخلية
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- شريط جانبي -->
                <div class="space-y-6">
                    <!-- بيانات المُشتكي -->
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <h3 class="font-bold mb-4">بيانات المُقدِّم</h3>
                        <div class="space-y-2 text-sm">
                            <div class="flex justify-between"><span class="text-muted">الاسم</span><span class="font-medium">${c.is_anonymous?'🎭 مجهول':escapeHtml(c.name)}</span></div>
                            <div class="flex justify-between"><span class="text-muted">الهاتف</span><span class="font-mono">${escapeHtml(c.phone||'—')}</span></div>
                            ${c.national_id?`<div class="flex justify-between"><span class="text-muted">البطاقة</span><span class="font-mono text-xs">${escapeHtml(c.national_id)}</span></div>`:''}
                            ${c.email?`<div class="flex justify-between"><span class="text-muted">البريد</span><span class="text-xs">${escapeHtml(c.email)}</span></div>`:''}
                            <div class="flex justify-between"><span class="text-muted">المنطقة</span><span>${escapeHtml(c.district||'—')}</span></div>
                        </div>
                    </div>

                    <!-- تغيير الحالة -->
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <h3 class="font-bold mb-4">تغيير الحالة</h3>
                        <select id="status-select" class="w-full px-3 py-2.5 border-2 rounded-xl input-focus text-sm" onchange="updateAdminStatus(${c.id})">
                            ${Object.keys(STATUS_CONFIG).map(s=>`<option value="${s}" ${c.status===s?'selected':''}>${s}</option>`).join('')}
                        </select>
                    </div>

                    <!-- تكليف لموظف -->
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <h3 class="font-bold mb-4">تكليف لموظف</h3>
                        <select id="assign-select" class="w-full px-3 py-2.5 border-2 rounded-xl input-focus text-sm mb-3" onchange="assignTo(${c.id})">
                            <option value="">-- غير مُكلَّف --</option>
                            ${users.map(u=>`<option value="${u.id}" ${c.assigned_to==u.id?'selected':''}>${escapeHtml(u.name)} (${u.role==='admin'?'مدير':'موظف'})</option>`).join('')}
                        </select>
                        ${c.assigned_to?`<p class="text-xs text-success">✓ مُكلَّف لـ: ${escapeHtml(c.assigned_name||'')}</p>`:''}
                    </div>

                    <!-- سجل الحالات -->
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <h3 class="font-bold mb-4">سجل الحالات</h3>
                        <div class="space-y-3">
                            ${history.map((h,i)=>{ const cfg=STATUS_CONFIG[h.status]||STATUS_CONFIG['تم الاستلام']; return `
                            <div class="timeline-item ${i>0?'opacity-60':''}">
                                <div class="timeline-dot" style="background:${cfg.color}"></div>
                                <div>
                                    <span class="text-sm font-medium" style="color:${cfg.color}">${h.status}</span>
                                    <div class="text-xs text-muted">${formatDate(h.timestamp)}</div>
                                </div>
                            </div>`; }).join('')}
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>`;
}

async function updateAdminStatus(id) {
    const s=document.getElementById('status-select')?.value; if(!s) return;
    const r=await Store.updateComplaint(id,{status:s});
    if(r?.success){showNotification('تم تحديث الحالة','success');navigateTo('admin-complaint-detail',{id});}
    else showNotification('فشل التحديث','error');
}

async function assignTo(id) {
    const uid=document.getElementById('assign-select')?.value;
    const r=await Store.assignComplaint(id,uid?parseInt(uid):0);
    if(r?.success) showNotification('تم التكليف','success');
    else showNotification('فشل التكليف','error');
}

async function submitAdminComment(id,isInternal=false) {
    const m=document.getElementById('admin-comment')?.value.trim();
    const fileInput=document.getElementById('admin-file');
    if(!m&&(!fileInput||fileInput.files.length===0)) return showNotification('اكتب رداً أو أرفق ملفاً','error');

    const fd=new FormData();
    fd.append('complaint_id',id);
    fd.append('message',m||'');
    fd.append('is_internal',isInternal?'1':'0');
    if(fileInput?.files.length>0) fd.append('file',fileInput.files[0]);

    try {
        const res=await fetch('api/admin.php?action=add_comment',{method:'POST',body:fd,credentials:'include'});
        const result=JSON.parse((await res.text()).trim());
        if(result.success){
            showNotification(isInternal?'تم حفظ الملاحظة الداخلية':'تم إرسال الرد','success');
            navigateTo('admin-complaint-detail',{id});
        } else showNotification(result.message||'فشل','error');
    } catch(e){showNotification('خطأ في الاتصال','error');}
}

function printComplaintDetail() {
    const area=document.getElementById('complaint-detail-print');
    if(!area) return;
    const w=window.open('','_blank');
    w.document.write(`<html dir="rtl"><head><title>تفاصيل الشكوى</title><style>body{font-family:Arial,sans-serif;font-size:13px} .bg-white{border:1px solid #e2e8f0;border-radius:8px;padding:16px;margin-bottom:16px} .text-muted{color:#64748b} .font-bold{font-weight:bold} .font-mono{font-family:monospace} table{width:100%;border-collapse:collapse} td{padding:4px 8px}</style></head><body>${area.innerHTML}</body></html>`);
    w.document.close(); w.print();
}

// ==========================================
// ADMIN USERS
// ==========================================
async function renderAdminUsers() {
    if(!requireAdminPage()) return '';
    const users=await Store.getUsers();
    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('users')}
        <main class="flex-1 p-6 overflow-auto">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold">المستخدمين (${users.length})</h1>
                <button onclick="showAddUserModal()" class="btn-primary px-5 py-2.5 rounded-xl font-medium text-sm">+ إضافة مستخدم</button>
            </div>
            <div class="bg-white rounded-2xl shadow-sm overflow-hidden mb-6">
                <div class="overflow-x-auto"><table class="w-full text-right text-sm">
                    <thead class="bg-slate-50 border-b"><tr>
                        <th class="p-4">الاسم</th><th class="p-4">البريد</th><th class="p-4">الهاتف</th><th class="p-4">الدور</th><th class="p-4">تاريخ الإضافة</th><th class="p-4"></th>
                    </tr></thead>
                    <tbody>
                        ${users.map(u=>`<tr class="border-b hover:bg-slate-50">
                            <td class="p-4 font-medium">${escapeHtml(u.name)}</td>
                            <td class="p-4 text-muted">${escapeHtml(u.email)}</td>
                            <td class="p-4 text-muted">${u.phone||'—'}</td>
                            <td class="p-4"><span class="px-2 py-1 rounded-full text-xs font-medium ${u.role==='admin'?'bg-primary/10 text-primary':'bg-blue-50 text-blue-600'}">${u.role==='admin'?'🔑 مدير':'👤 موظف'}</span></td>
                            <td class="p-4 text-muted text-xs">${formatDate(u.created_at)}</td>
                            <td class="p-4">${u.id!==Store.data.currentUser?.id?`<button onclick="confirmDeleteUser(${u.id},'${escapeHtml(u.name)}')" class="text-danger hover:underline text-xs">حذف</button>`:'<span class="text-xs text-muted">أنت</span>'}</td>
                        </tr>`).join('')}
                    </tbody>
                </table></div>
            </div>
        </main>
    </div>
    <!-- Modal -->
    <div id="add-user-modal" class="fixed inset-0 z-50 hidden items-center justify-center" style="background:rgba(15,23,42,0.7);backdrop-filter:blur(4px)">
        <div class="bg-white rounded-2xl shadow-xl p-6 w-full max-w-md mx-4">
            <div class="flex justify-between items-center mb-6"><h2 class="text-xl font-bold">إضافة مستخدم</h2><button onclick="hideAddUserModal()" class="text-muted text-xl">✕</button></div>
            <div class="space-y-4">
                <div><label class="block text-sm font-medium mb-1">الاسم <span class="text-danger">*</span></label><input type="text" id="new-name" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus" placeholder="محمد أحمد"></div>
                <div><label class="block text-sm font-medium mb-1">البريد <span class="text-danger">*</span></label><input type="email" id="new-email" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus" placeholder="user@example.com"></div>
                <div><label class="block text-sm font-medium mb-1">كلمة المرور <span class="text-danger">*</span></label><input type="password" id="new-password" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus" placeholder="8 أحرف على الأقل"></div>
                <div><label class="block text-sm font-medium mb-1">الهاتف</label><input type="tel" id="new-phone" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus" placeholder="01012345678"></div>
                <div><label class="block text-sm font-medium mb-1">الدور</label>
                    <select id="new-role" class="w-full px-4 py-2.5 border-2 rounded-xl input-focus">
                        <option value="agent">موظف — يتابع ويرد على الشكاوى</option>
                        <option value="admin">مدير — صلاحيات كاملة</option>
                    </select></div>
            </div>
            <div class="flex gap-3 mt-6">
                <button onclick="hideAddUserModal()" class="flex-1 px-4 py-2.5 rounded-xl border-2 border-slate-200">إلغاء</button>
                <button onclick="handleAddUser()" class="flex-1 btn-primary px-4 py-2.5 rounded-xl font-medium">إضافة</button>
            </div>
        </div>
    </div>`;
}

function showAddUserModal(){const m=document.getElementById('add-user-modal');if(m){m.classList.remove('hidden');m.classList.add('flex');}}
function hideAddUserModal(){const m=document.getElementById('add-user-modal');if(m){m.classList.add('hidden');m.classList.remove('flex');}}
async function handleAddUser(){
    const data={name:document.getElementById('new-name')?.value.trim(),email:document.getElementById('new-email')?.value.trim(),password:document.getElementById('new-password')?.value,phone:document.getElementById('new-phone')?.value.trim(),role:document.getElementById('new-role')?.value};
    if(!data.name||!data.email||!data.password) return showNotification('أكمل الحقول المطلوبة','error');
    if(data.password.length<8) return showNotification('كلمة المرور 8 أحرف على الأقل','error');
    const r=await Store.addUser(data);
    if(r.success){showNotification('تمت الإضافة','success');hideAddUserModal();navigateTo('admin-users');}
    else showNotification(r.message||'فشل الإضافة','error');
}
async function confirmDeleteUser(id,name){
    if(!confirm(`هل تريد حذف "${name}"؟`)) return;
    const r=await Store.deleteUser(id);
    if(r.success){showNotification('تم الحذف','success');navigateTo('admin-users');}
    else showNotification(r.message||'فشل الحذف','error');
}

// ==========================================
// ADMIN REPORTS
// ==========================================
async function renderAdminReports() {
    if(!requireAdminPage()) return '';
    const currentMonth=new Date().toISOString().substring(0,7);
    const report=await Store.getMonthlyReport(currentMonth);
    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('reports')}
        <main class="flex-1 p-6 overflow-auto">
            <div class="flex flex-wrap justify-between items-center gap-4 mb-6">
                <h1 class="text-2xl font-bold">التقارير الشهرية</h1>
                <div class="flex items-center gap-3">
                    <input type="month" id="report-month" value="${currentMonth}" onchange="loadMonthReport(this.value)" class="px-3 py-2 border-2 rounded-xl text-sm input-focus">
                    <button onclick="window.print()" class="flex items-center gap-2 border-2 border-slate-200 px-4 py-2 rounded-xl text-sm hover:bg-slate-50">🖨️ طباعة</button>
                </div>
            </div>
            <div id="report-content">${renderReportContent(report)}</div>
        </main>
    </div>`;
}

function renderReportContent(report) {
    if(!report.success) return '<p class="text-muted text-center py-12">لا توجد بيانات لهذا الشهر</p>';
    const total=report.total||1;
    const byStatus=report.by_status||{};
    const byCat=report.by_category||{};
    const byType=report.by_type||{'شكوى':0,'طلب':0};

    return `
    <!-- ملخص سريع مع تفريق شكاوى/طلبات -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <div class="bg-white rounded-2xl shadow-sm p-6 text-center"><div class="text-3xl font-bold text-primary">${report.total}</div><div class="text-muted text-sm">إجمالي الشهر</div></div>
        <div class="bg-white rounded-2xl shadow-sm p-6 text-center"><div class="text-3xl font-bold text-blue-600">${byType['شكوى']||0}</div><div class="text-muted text-sm">📢 شكاوى</div></div>
        <div class="bg-white rounded-2xl shadow-sm p-6 text-center"><div class="text-3xl font-bold text-orange-600">${byType['طلب']||0}</div><div class="text-muted text-sm">📋 طلبات</div></div>
        <div class="bg-white rounded-2xl shadow-sm p-6 text-center"><div class="text-3xl font-bold text-success">${report.solved}</div><div class="text-muted text-sm">تم حلها (${Math.round(report.solved/total*100)}%)</div></div>
    </div>

    <div class="grid md:grid-cols-2 gap-6 mb-6">
        <div class="bg-white rounded-2xl shadow-sm p-6">
            <h2 class="font-bold text-lg mb-4">توزيع حسب الحالة</h2>
            <div class="space-y-3">
                ${Object.entries(byStatus).map(([s,count])=>{ const cfg=STATUS_CONFIG[s]||{color:'#6b7280'}; const pct=Math.round(count/total*100); return `<div><div class="flex justify-between mb-1"><span class="text-sm">${s}</span><span class="text-sm font-bold">${count} (${pct}%)</span></div><div class="w-full bg-slate-100 rounded-full h-2"><div class="h-2 rounded-full" style="width:${pct}%;background:${cfg.color}"></div></div></div>`; }).join('')}
            </div>
        </div>
        <div class="bg-white rounded-2xl shadow-sm p-6">
            <h2 class="font-bold text-lg mb-4">توزيع حسب الفئة</h2>
            <div class="space-y-3">
                ${Object.entries(byCat).map(([cat,count])=>{ const cfg=CATEGORY_CONFIG[cat]||{icon:'📋',color:'#6b7280'}; const pct=Math.round(count/total*100); return `<div class="flex items-center gap-3"><span class="text-xl w-7 flex-shrink-0">${cfg.icon}</span><div class="flex-1"><div class="flex justify-between mb-1"><span class="text-sm">${cat}</span><span class="text-sm font-bold">${count}</span></div><div class="w-full bg-slate-100 rounded-full h-2"><div class="h-2 rounded-full" style="width:${pct}%;background:${cfg.color}"></div></div></div></div>`; }).join('')}
            </div>
        </div>
    </div>

    <!-- جدول تفصيلي مع تمييز النوع -->
    <div class="bg-white rounded-2xl shadow-sm p-6">
        <h2 class="font-bold text-lg mb-4">تفاصيل الشهر — شكاوى وطلبات (${report.complaints?.length||0})</h2>
        ${!report.complaints?.length?'<p class="text-muted text-center py-6">لا توجد بيانات</p>':
        `<div class="overflow-x-auto"><table class="w-full text-right text-sm">
            <thead class="bg-slate-50 border-b"><tr>
                <th class="p-3">الكود</th><th class="p-3">النوع</th><th class="p-3">العنوان</th><th class="p-3">الفئة</th><th class="p-3">المنطقة</th><th class="p-3">الحالة</th><th class="p-3">التاريخ</th>
            </tr></thead>
            <tbody>${report.complaints.map(c=>`<tr class="border-b hover:bg-slate-50" style="border-right:3px solid ${STATUS_CONFIG[c.status]?.color||'#e2e8f0'}">
                <td class="p-3 font-mono text-xs text-primary font-bold">${escapeHtml(c.complaint_code||c.id)}</td>
                <td class="p-3"><span class="text-xs px-2 py-0.5 rounded-full ${c.submission_type==='طلب'?'bg-orange-100 text-orange-700':'bg-primary/10 text-primary'}">${c.submission_type||'شكوى'}</span></td>
                <td class="p-3 max-w-xs"><div class="truncate">${escapeHtml(c.title)}</div></td>
                <td class="p-3 text-xs">${CATEGORY_CONFIG[c.category]?.icon||'📋'} ${c.category}</td>
                <td class="p-3 text-xs text-muted">${c.district||'—'}</td>
                <td class="p-3">${statusBadge(c.status)}</td>
                <td class="p-3 text-muted text-xs">${formatDate(c.created_at)}</td>
            </tr>`).join('')}</tbody>
        </table></div>`}
    </div>`;
}

async function loadMonthReport(month) {
    const c=document.getElementById('report-content');
    if(c) c.innerHTML='<div class="flex justify-center py-12"><div class="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div></div>';
    const report=await Store.getMonthlyReport(month);
    if(c) c.innerHTML=renderReportContent(report);
}

// ==========================================
// AGENT PANEL
// ==========================================
async function renderAgentPanel() {
    if(!Store.data.currentUser){window.location.href='dashboard.php';return '';}
    const user=Store.data.currentUser;
    const complaints=await Store.getComplaints();
    const open=complaints.filter(c=>!['تم الحل','مغلقة','مرفوضة'].includes(c.status));
    return `
    <div class="flex min-h-screen bg-slate-100">
        <aside class="sidebar fixed lg:static inset-y-0 right-0 w-64 bg-secondary text-white z-40 flex flex-col">
            <div class="p-5 border-b border-slate-700"><div class="font-bold">👤 لوحة الموظف</div><div class="text-xs text-slate-400 mt-1">${escapeHtml(user.name)}</div></div>
            <div class="flex-1 p-4"></div>
            <div class="p-4 border-t border-slate-700">
                <a href="/" class="block text-center text-xs text-slate-500 hover:text-slate-300 mb-2">← الموقع الرئيسي</a>
                <button onclick="logout()" class="w-full py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-sm">تسجيل الخروج</button>
            </div>
        </aside>
        <main class="flex-1 p-6 overflow-auto">
            <h1 class="text-2xl font-bold mb-2">الشكاوى والطلبات المفتوحة</h1>
            <p class="text-muted text-sm mb-6">(${open.length}) تحتاج متابعة</p>
            ${open.length===0?`<div class="bg-white rounded-2xl p-12 text-center"><div class="text-5xl mb-4">✅</div><h2 class="font-bold text-lg">لا توجد شكاوى مفتوحة</h2></div>`:
            `<div class="grid gap-4">${open.map(c=>`
            <div class="bg-white rounded-2xl shadow-sm p-5 flex flex-wrap justify-between items-start gap-4" style="border-right:4px solid ${STATUS_CONFIG[c.status]?.color||'#0d9488'}">
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 mb-1">
                        <span class="font-mono text-xs text-primary font-bold">${escapeHtml(c.complaint_code||c.id)}</span>
                        <span class="text-xs px-2 py-0.5 rounded-full ${c.submission_type==='طلب'?'bg-orange-100 text-orange-700':'bg-primary/10 text-primary'}">${c.submission_type||'شكوى'}</span>
                        ${statusBadge(c.status)}
                    </div>
                    <h3 class="font-bold truncate">${escapeHtml(c.title)}</h3>
                    <p class="text-sm text-muted mt-1">${CATEGORY_CONFIG[c.category]?.icon||'📋'} ${c.category} · ${c.district||''} · ${formatDate(c.created_at)}</p>
                </div>
                <button onclick="navigateTo('admin-complaint-detail',{id:${c.id}})" class="btn-primary px-4 py-2 rounded-lg text-sm font-medium flex-shrink-0">عرض / رد</button>
            </div>`).join('')}</div>`}
        </main>
    </div>`;
}

// ==========================================
// INIT
// ==========================================
(function init() {
    const urlParams=new URLSearchParams(window.location.search);
    const isGoto=urlParams.get('goto')==='dashboard'||window.location.hash==='#dashboard';
    if(isGoto) { window.history.replaceState(null,'',window.location.pathname); verifySessionWithServer(); }
    else renderPage();
})();

async function verifySessionWithServer() {
    try {
        const res=await fetch('api/admin.php?action=whoami',{credentials:'include'});
        const txt=await res.text();
        const clean=txt.trim().replace(/^\uFEFF/,'');
        if(clean.startsWith('{')) {
            const data=JSON.parse(clean);
            if(data.success&&data.user) { Store.data.currentUser=data.user; navigateTo(data.user.role==='admin'?'admin':'agent'); return; }
        }
    } catch(e){console.error('whoami:',e);}
    renderPage();
}

// ==========================================
// ADMIN STATUS REQUESTS
// ==========================================
async function renderAdminStatusRequests() {
    if(!requireAdminPage()) return '';
    const requests = await Store.getStatusRequests();
    return `
    <div class="flex min-h-screen bg-slate-100">
        ${renderAdminSidebar('requests')}
        <main class="flex-1 p-6 overflow-auto">
            <h1 class="text-2xl font-bold mb-6">طلبات تغيير الحالة (${requests.length})</h1>
            ${requests.length === 0 ? 
                '<div class="bg-white rounded-2xl p-12 text-center"><div class="text-5xl mb-4">✅</div><h2 class="font-bold text-lg">لا توجد طلبات معلقة</h2></div>' :
                `<div class="space-y-4">${requests.map(req => `
                    <div class="bg-white rounded-2xl shadow-sm p-6">
                        <div class="flex flex-wrap justify-between items-start gap-4">
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-2">
                                    <span class="font-mono text-xs text-primary font-bold">${escapeHtml(req.complaint_code)}</span>
                                    <span class="text-sm text-muted">مقدم من: ${escapeHtml(req.requester_name)}</span>
                                </div>
                                <h3 class="font-bold mb-1">${escapeHtml(req.title)}</h3>
                                <div class="flex items-center gap-3 text-sm">
                                    <span>الحالة الحالية: ${statusBadge(req.current_status)}</span>
                                    <span>→</span>
                                    <span>المطلوب: ${statusBadge(req.requested_status)}</span>
                                </div>
                                ${req.reason ? `<p class="text-sm text-muted mt-2 bg-slate-50 rounded-lg p-3">💬 ${escapeHtml(req.reason)}</p>` : ''}
                                <p class="text-xs text-muted mt-2">${formatDate(req.created_at)} · ${formatTime(req.created_at)}</p>
                            </div>
                            <div class="flex gap-2 flex-shrink-0">
                                <button onclick="handleStatusRequest(${req.id}, ${req.complaint_id}, true)" 
                                        class="px-4 py-2 bg-success text-white rounded-lg text-sm font-medium hover:bg-green-600">✓ موافقة</button>
                                <button onclick="handleStatusRequest(${req.id}, ${req.complaint_id}, false)" 
                                        class="px-4 py-2 bg-danger text-white rounded-lg text-sm font-medium hover:bg-red-600">✕ رفض</button>
                            </div>
                        </div>
                    </div>`).join('')}</div>`
            }
        </main>
    </div>`;
}

async function handleStatusRequest(requestId, complaintId, approve) {
    const action = approve ? 'الموافقة' : 'الرفض';
    if (!confirm(\`هل أنت متأكد من \${action} على هذا الطلب؟\`)) return;
    const result = await Store.approveStatusChange(requestId, approve);
    if (result?.success) {
        showNotification(result.message, 'success');
        navigateTo('admin-requests');
    } else {
        showNotification(result?.message || 'فشل ' + action, 'error');
    }
}
